const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_jarvis_01";
const BOB_UID = "bob_jarvis_02";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function safePastTimestamp() {
  return new Date(Date.now() - 5000);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write deleteRecords", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("deleteRecords").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
});

test("Owner can create, read, and update deleteRecords; cross-user access denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const recordRef = aliceDb.collection("users").doc(ALICE_UID).collection("deleteRecords").doc("rec_1");
  const ts = safePastTimestamp();

  await assertSucceeds(recordRef.set({
    userId: ALICE_UID,
    itemTitle: "IMG_20261113_01.jpg",
    itemType: "photo",
    sourceApp: "Gallery",
    details: "Deleted after confirmation",
    dateKey: "2026-11-13",
    deletedAtEpochMs: 1794589000000,
    createdAt: ts,
    updatedAt: ts,
  }));

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("deleteRecords").get());
  await assertSucceeds(recordRef.update({
    details: "Updated note after 8 days",
    updatedAt: safePastTimestamp(),
  }));

  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("deleteRecords").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("deleteRecords").doc("rec_1").get());
});

test("Shadow update with ghost field or invalid enum is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const badTypeRef = aliceDb.collection("users").doc(ALICE_UID).collection("deleteRecords").doc("rec_bad");
  const ts = safePastTimestamp();

  await assertFails(badTypeRef.set({
    userId: ALICE_UID,
    itemTitle: "Test",
    itemType: "executable",
    sourceApp: "Gallery",
    details: "",
    dateKey: "2026-11-13",
    deletedAtEpochMs: 1794589000000,
    createdAt: ts,
    updatedAt: ts,
  }));

  const ghostRef = aliceDb.collection("users").doc(ALICE_UID).collection("allowlistContacts").doc("c_1");
  await assertFails(ghostRef.set({
    userId: ALICE_UID,
    name: "Pepper",
    phoneNumber: "+919876543210",
    relationship: "Family",
    isAllowlisted: true,
    isBlockedSpam: false,
    isAdmin: true,
    createdAt: ts,
    updatedAt: ts,
  }));
});

test("Owner can create and update userProfile, allowlistContacts, socialReports, simPlans, voiceProfiles", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const ts = safePastTimestamp();

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).set({
    userId: ALICE_UID,
    displayName: "Tony",
    preferredVoiceId: "jarvis_classic",
    customUserVoiceConsent: false,
    wakeWordEnabled: true,
    batteryAlertsEnabled: true,
    preferredLanguage: "auto",
    createdAt: ts,
    updatedAt: ts,
  }));

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("allowlistContacts").doc("c_1").set({
    userId: ALICE_UID,
    name: "Pepper Potts",
    phoneNumber: "+919876543210",
    relationship: "Partner",
    isAllowlisted: true,
    isBlockedSpam: false,
    createdAt: ts,
    updatedAt: ts,
  }));

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("socialReports").doc("rep_1").set({
    userId: ALICE_UID,
    platform: "facebook",
    periodType: "daily",
    dateKey: "2026-11-13",
    totalFollowers: 15200,
    newFollowers: 120,
    viewsOrImpressions: 42000,
    likes: 3400,
    comments: 210,
    shares: 95,
    messagesCount: 18,
    earningsInr: 1450.5,
    dataSource: "Meta Business Suite (Official)",
    unfollowersNote: "Not provided by Meta API",
    createdAt: ts,
    updatedAt: ts,
  }));

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("simPlans").doc("sim_1").set({
    userId: ALICE_UID,
    simSlot: 1,
    operatorName: "Jio",
    planName: "True 5G 299",
    planPriceInr: 299,
    remainingDataGb: 1.5,
    validityDays: 24,
    expiryDateKey: "2026-12-07",
    createdAt: ts,
    updatedAt: ts,
  }));

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("voiceProfiles").doc("v_1").set({
    userId: ALICE_UID,
    name: "User Custom",
    description: "User consented custom voice profile",
    pitch: 1.0,
    speechRate: 1.0,
    isUserOwnVoice: true,
    consentGranted: true,
    createdAt: ts,
    updatedAt: ts,
  }));
});
