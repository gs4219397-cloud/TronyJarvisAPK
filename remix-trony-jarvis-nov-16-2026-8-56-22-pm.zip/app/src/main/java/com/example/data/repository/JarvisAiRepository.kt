package com.example.data.repository

import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import com.example.data.model.MovieSearchResult
import com.example.data.model.ShoppingProduct
import com.example.data.model.TicketBookingOption
import com.example.data.model.VisionAnalysisResult
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

sealed interface AiIntentAction {
    data class ChatReply(val replyText: String) : AiIntentAction
    data class CallContact(val targetNameOrNumber: String) : AiIntentAction
    data class DraftSocialMessage(val platform: String, val recipient: String, val text: String) : AiIntentAction
    data object ShareLiveLocation : AiIntentAction
    data class LockScreen(val isLock: Boolean) : AiIntentAction
    data object CheckBattery : AiIntentAction
    data object CheckSim : AiIntentAction
    data class SearchShopping(val query: String) : AiIntentAction
    data class SearchMovie(val query: String) : AiIntentAction
    data class DeleteGalleryItem(val itemHint: String) : AiIntentAction
    data class SocialReportQuery(val periodHint: String) : AiIntentAction
}

class JarvisAiRepository {

    private val chatModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_FLASH,
            systemInstruction = content {
                text(
                    """
                    You are TRONY AI JARVIS, a brilliant, warm, polite, human-like personal AI assistant inspired by Tony Stark's JARVIS.
                    CRITICAL MULTILINGUAL RULE:
                    - Understand Hindi, Bengali, Tamil, English, Hinglish, and any other language the user speaks or types.
                    - ALWAYS respond in the EXACT SAME language and script (or natural Hinglish/Hindi if spoken in Hindi) that the user used!
                    - Keep voice replies crisp, intelligent, respectful, and conversational (2-4 sentences unless the user asks for detailed steps).
                    - Never invent private user passwords, PINs, OTPs, CVVs, or fake social media earnings.
                    - If asked about a device action (call, SMS/WhatsApp, live location, lock/unlock, battery, SIM, gallery delete, social report, shopping, movie search), acknowledge clearly and accurately.
                    """.trimIndent()
                )
            }
        )
    }

    private val visionSchema = Schema.obj(
        properties = mapOf(
            "appearanceSummary" to Schema.string(description = "Brief natural description of the visible person/scene in the requested language"),
            "beardAndMoustache" to Schema.string(description = "Visible beard and moustache details, or none observed"),
            "hairstyle" to Schema.string(description = "Visible hairstyle description"),
            "outfitAndColors" to Schema.string(description = "Shirt, T-shirt, pants, and clothing colors observed"),
            "observedExpression" to Schema.string(description = "Visible facial expression such as smiling, calm, serious, tired"),
            "expressionDisclaimer" to Schema.string(description = "Clear note that visible expression is an observation, not a guarantee of true emotion"),
            "moodCategory" to Schema.enumeration(listOf("upbeat", "soothing"), description = "upbeat if smiling/bright, soothing if calm/tired/sad-looking"),
            "musicSuggestionQuery" to Schema.string(description = "Recommended YouTube music search query matching mood"),
            "musicReason" to Schema.string(description = "Friendly one-sentence reason for the music recommendation")
        )
    )

    private val visionModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_FLASH,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = visionSchema
            }
        )
    }

    private val shoppingSchema = Schema.obj(
        properties = mapOf(
            "products" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "name" to Schema.string(),
                        "platform" to Schema.string(description = "Amazon, Flipkart, or Meesho"),
                        "priceInr" to Schema.string(description = "Price in INR e.g. Rs 17,999"),
                        "rating" to Schema.string(description = "Rating and review count summary"),
                        "seller" to Schema.string(description = "Typical authorized seller or marketplace note"),
                        "ramStorage" to Schema.string(),
                        "processor" to Schema.string(),
                        "camera" to Schema.string(),
                        "battery" to Schema.string(),
                        "display" to Schema.string(),
                        "deliveryAndTaxes" to Schema.string(description = "Delivery charge, GST inclusion, and shipping info")
                    )
                )
            )
        )
    )

    private val shoppingModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_FLASH,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = shoppingSchema
            }
        )
    }

    private val movieSchema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string(),
            "language" to Schema.string(),
            "year" to Schema.string(),
            "summary" to Schema.string(),
            "ottPlatforms" to Schema.array(items = Schema.string(), description = "Official streaming or rent platforms such as Netflix, YouTube Movies, Amazon Prime Video, JioHotstar"),
            "officialNote" to Schema.string(description = "Official watch, rent, purchase, or offline app-download guidance; never pirated links")
        )
    )

    private val movieModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_FLASH,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = movieSchema
            }
        )
    }

    private val ticketSchema = Schema.obj(
        properties = mapOf(
            "options" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "bookingType" to Schema.string(),
                        "title" to Schema.string(),
                        "dateText" to Schema.string(),
                        "timeText" to Schema.string(),
                        "seatInfo" to Schema.string(),
                        "estimatedPriceInr" to Schema.string(),
                        "officialPlatformName" to Schema.string()
                    )
                )
            )
        )
    )

    private val ticketModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_FLASH,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = ticketSchema
            }
        )
    }

    fun streamConversationalReply(
        userPrompt: String,
        preferredLanguage: String,
        contextSummary: String
    ): Flow<String> = flow {
        val fullPrompt = buildString {
            if (preferredLanguage != "auto") {
                append("User preferred language hint: $preferredLanguage (still reply in the user's message language if different).\n")
            }
            if (contextSummary.isNotBlank()) {
                append("Real-time device telemetry context:\n$contextSummary\n\n")
            }
            append("User message: $userPrompt")
        }

        val accumulated = StringBuilder()
        try {
            withTimeout(AI_TIMEOUT_MS) {
                chatModel.generateContentStream(fullPrompt).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        accumulated.append(piece)
                        emit(accumulated.toString())
                    }
                }
            }
            if (accumulated.isBlank()) {
                throw IllegalStateException("Gemini returned an empty response.")
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Streaming timed out", e)
            throw IllegalStateException("AI response timed out after 60 seconds. Please try again.", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI streaming failed", e)
            throw e
        }
    }

    suspend fun analyzeVisionFrame(bitmap: Bitmap, userLanguageHint: String): VisionAnalysisResult {
        val prompt = """
            Analyze this image carefully as TRONY AI JARVIS Vision Assistant.
            Respond in the user's language hint ($userLanguageHint; default Hindi/English mix if 'auto' or English if requested).
            Describe:
            1. Visible appearance summary of any person in view (or scene if no person).
            2. Beard and moustache details (if visible).
            3. Hairstyle details (if visible).
            4. Shirt, T-shirt, pants, and clothing colors / full outfit.
            5. Visible facial expression (e.g. smiling, neutral, focused, tired).
            6. Clear disclaimer that visible expression is only an observation and cannot definitively claim internal emotion.
            7. Mood category ('upbeat' if smiling/happy-looking, 'soothing' if calm/tired/sad-looking) and a YouTube music query suggestion.
        """.trimIndent()

        return try {
            val response = withTimeout(AI_TIMEOUT_MS) {
                visionModel.generateContent(
                    content {
                        image(bitmap)
                        text(prompt)
                    }
                )
            }
            val raw = response.text ?: throw IllegalStateException("Vision model returned empty output.")
            val json = JSONObject(raw)
            VisionAnalysisResult(
                appearanceSummary = json.optString("appearanceSummary", "Person in frame analyzed."),
                beardAndMoustache = json.optString("beardAndMoustache", "Not clearly visible"),
                hairstyle = json.optString("hairstyle", "Not clearly visible"),
                outfitAndColors = json.optString("outfitAndColors", "Clothing details not clearly visible"),
                observedExpression = json.optString("observedExpression", "Neutral / calm expression"),
                expressionDisclaimer = json.optString(
                    "expressionDisclaimer",
                    "Note: Visible expression is only a visual cue and does not prove true feelings."
                ),
                moodCategory = json.optString("moodCategory", "upbeat"),
                musicSuggestionQuery = json.optString("musicSuggestionQuery", "Feel good Bollywood upbeat acoustic"),
                musicReason = json.optString("musicReason", "Matched to your observed vibe.")
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Vision analysis timed out", e)
            throw IllegalStateException("Vision analysis timed out. Please try again.", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Vision analysis failed", e)
            throw e
        }
    }

    suspend fun searchShoppingProducts(query: String): List<ShoppingProduct> {
        val prompt = """
            Find and compare 4 realistic Indian e-commerce product options for: "$query".
            Include options across Amazon, Flipkart, and Meesho where relevant.
            For phones/electronics include exact RAM, storage, processor, camera, battery, display.
            For non-electronics fill those specification fields with relevant category attributes (material, size, warranty, weight).
            Include price in INR (₹), rating summary, typical authorized seller, and delivery/GST note.
        """.trimIndent()

        return try {
            val response = withTimeout(AI_TIMEOUT_MS) {
                shoppingModel.generateContent(prompt)
            }
            val raw = response.text ?: throw IllegalStateException("Shopping model returned empty output.")
            val root = JSONObject(raw)
            val arr = root.getJSONArray("products")
            (0 until arr.length()).map { idx ->
                val obj = arr.getJSONObject(idx)
                val name = obj.optString("name", query)
                val platform = obj.optString("platform", "Amazon")
                val encoded = Uri.encode(name)
                val url = when {
                    platform.contains("flipkart", ignoreCase = true) ->
                        "https://www.flipkart.com/search?q=$encoded"
                    platform.contains("meesho", ignoreCase = true) ->
                        "https://www.meesho.com/search?q=$encoded"
                    else ->
                        "https://www.amazon.in/s?k=$encoded"
                }
                ShoppingProduct(
                    name = name,
                    platform = platform,
                    priceInr = obj.optString("priceInr", "Check live price"),
                    rating = obj.optString("rating", "4.3★"),
                    seller = obj.optString("seller", "Verified Seller"),
                    ramStorage = obj.optString("ramStorage", "Standard"),
                    processor = obj.optString("processor", "Standard"),
                    camera = obj.optString("camera", "N/A"),
                    battery = obj.optString("battery", "N/A"),
                    display = obj.optString("display", "N/A"),
                    deliveryAndTaxes = obj.optString("deliveryAndTaxes", "GST included; check shipping at checkout"),
                    searchUrl = url
                )
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Shopping search timed out", e)
            throw IllegalStateException("Shopping search timed out. Please try again.", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Shopping search failed", e)
            throw e
        }
    }

    suspend fun searchOfficialMovie(query: String): MovieSearchResult {
        val prompt = """
            Provide accurate information for the movie "$query".
            Include title, language, release year, concise summary, and official legal OTT platforms (like Netflix, YouTube Movies, Amazon Prime Video, JioHotstar, Apple TV) for streaming, rent, purchase, or official in-app offline download.
            NEVER mention or suggest pirated websites or unofficial downloads.
        """.trimIndent()

        return try {
            val response = withTimeout(AI_TIMEOUT_MS) {
                movieModel.generateContent(prompt)
            }
            val raw = response.text ?: throw IllegalStateException("Movie model returned empty output.")
            val json = JSONObject(raw)
            val platformsArr = json.optJSONArray("ottPlatforms")
            val platforms = if (platformsArr != null) {
                (0 until platformsArr.length()).map { platformsArr.getString(it) }
            } else {
                listOf("YouTube Movies", "Netflix", "Amazon Prime Video")
            }
            MovieSearchResult(
                title = json.optString("title", query),
                language = json.optString("language", "Hindi / English"),
                year = json.optString("year", ""),
                summary = json.optString("summary", "Movie details retrieved."),
                ottPlatforms = platforms,
                officialNote = json.optString(
                    "officialNote",
                    "Use official OTT apps or YouTube Movies for legal streaming, rent, purchase, and offline downloads."
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Movie search timed out", e)
            throw IllegalStateException("Movie search timed out. Please try again.", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Movie search failed", e)
            throw e
        }
    }

    suspend fun planTicketBooking(bookingType: String, query: String, date: String): List<TicketBookingOption> {
        val prompt = """
            Prepare 3 realistic official booking option templates for $bookingType in India: "$query" on date "$date".
            Include title (e.g., train name/number or movie theater showtime), dateText, timeText, seatInfo (class or seat tier), estimatedPriceInr, and officialPlatformName (e.g., IRCTC Rail Connect, BookMyShow, RedBus, Paytm).
            Remind that final seat availability and payment happen on the official platform.
        """.trimIndent()

        return try {
            val response = withTimeout(AI_TIMEOUT_MS) {
                ticketModel.generateContent(prompt)
            }
            val raw = response.text ?: throw IllegalStateException("Ticket model returned empty output.")
            val arr = JSONObject(raw).getJSONArray("options")
            (0 until arr.length()).map { idx ->
                val obj = arr.getJSONObject(idx)
                val platform = obj.optString("officialPlatformName", "IRCTC")
                val url = when {
                    bookingType.contains("train", ignoreCase = true) || platform.contains("irctc", ignoreCase = true) ->
                        "https://www.irctc.co.in/nget/train-search"
                    bookingType.contains("movie", ignoreCase = true) || platform.contains("bookmyshow", ignoreCase = true) ->
                        "https://in.bookmyshow.com/explore/movies"
                    else ->
                        "https://www.google.com/search?q=${Uri.encode("$bookingType $query tickets official")}"
                }
                TicketBookingOption(
                    bookingType = obj.optString("bookingType", bookingType),
                    title = obj.optString("title", query),
                    dateText = obj.optString("dateText", date),
                    timeText = obj.optString("timeText", "10:30 AM"),
                    seatInfo = obj.optString("seatInfo", "Standard / Sleeper"),
                    estimatedPriceInr = obj.optString("estimatedPriceInr", "₹450 - ₹1,200"),
                    officialPlatformName = platform,
                    officialUrl = url
                )
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Ticket planning timed out", e)
            throw IllegalStateException("Ticket lookup timed out. Please try again.", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Ticket planning failed", e)
            throw e
        }
    }

    /**
     * Lightweight deterministic command parser for instant hands-free device actions
     * alongside Gemini conversational intelligence.
     */
    fun detectLocalIntent(input: String): AiIntentAction? {
        val text = input.trim()
        val lower = text.lowercase()

        return when {
            lower.contains("lock कर") || lower.contains("lock the screen") || lower.contains("screen lock") ||
                lower == "lock" || lower.contains("lock kar do") ->
                AiIntentAction.LockScreen(isLock = true)

            lower.contains("unlock कर") || lower.contains("unlock the screen") || lower.contains("unlock kar do") ->
                AiIntentAction.LockScreen(isLock = false)

            lower.contains("live location") || lower.contains("लोकेशन भेज") || lower.contains("location भेज") ->
                AiIntentAction.ShareLiveLocation

            lower.contains("battery") || lower.contains("बैटरी") || lower.contains("charge") ->
                AiIntentAction.CheckBattery

            lower.contains("sim") || lower.contains("recharge") || lower.contains("रिचार्ज") ||
                lower.contains("jio") || lower.contains("airtel") || lower.contains("bsnl") ->
                AiIntentAction.CheckSim

            lower.contains("gallery") && (lower.contains("delete") || lower.contains("डिलीट")) ->
                AiIntentAction.DeleteGalleryItem(text)

            lower.contains("report") || lower.contains("followers") || lower.contains("earnings") ||
                lower.contains("कमाई") || lower.contains("हिसाब") ->
                AiIntentAction.SocialReportQuery(text)

            lower.contains("खोजो") && (lower.contains("phone") || lower.contains("₹") || lower.contains("amazon") || lower.contains("flipkart") || lower.contains("meesho")) ->
                AiIntentAction.SearchShopping(text)

            lower.contains("movie") || lower.contains("फिल्म") || lower.contains("ott") ->
                AiIntentAction.SearchMovie(text)

            lower.startsWith("call ") || lower.contains("को call") || lower.contains("कॉल करो") || lower.contains("phone लगा") -> {
                val target = text
                    .replace(Regex("(?i)(hi |tony |ai |jarvis[, ]*)"), "")
                    .replace(Regex("(?i)(call |को call करो|को कॉल करो|कॉल करो|call karo|ko call karo)"), "")
                    .trim()
                AiIntentAction.CallContact(target.ifBlank { text })
            }

            lower.contains("whatsapp") || lower.contains("sms") || lower.contains("message") ||
                lower.contains("मैसेज") || lower.contains("messenger") -> {
                val platform = when {
                    lower.contains("whatsapp") -> "WhatsApp"
                    lower.contains("messenger") -> "Messenger"
                    lower.contains("instagram") -> "Instagram"
                    lower.contains("facebook") -> "Facebook"
                    lower.contains("twitter") || lower.contains("x ") -> "X"
                    else -> "SMS"
                }
                AiIntentAction.DraftSocialMessage(platform, "", text)
            }

            else -> null
        }
    }

    private companion object {
        const val TAG = "JarvisAiRepository"
        const val MODEL_FLASH = "gemini-3.8-flash"
        const val AI_TIMEOUT_MS = 60_000L
    }
}
