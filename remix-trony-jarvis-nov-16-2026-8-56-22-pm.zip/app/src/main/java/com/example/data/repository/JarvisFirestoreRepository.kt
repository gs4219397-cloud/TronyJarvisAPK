package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.AllowlistContact
import com.example.data.model.DeleteRecord
import com.example.data.model.SimPlan
import com.example.data.model.SocialReport
import com.example.data.model.UserProfile
import com.example.data.model.VoiceProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class JarvisFirestoreRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun userDoc(uid: String) = db.collection("users").document(uid)

    // --- User Profile ---

    fun observeUserProfile(userId: String): Flow<UserProfile?> =
        userDoc(userId)
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                logFlowErrorIfSignedIn(userId, error, OperationType.GET, "users/$userId")
                throw error
            }

    suspend fun ensureUserProfile(userId: String, displayName: String) {
        val docRef = userDoc(userId)
        try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val safeName = displayName.ifBlank { "Tony" }.take(80)
                val payload = mapOf(
                    "userId" to userId,
                    "displayName" to safeName,
                    "preferredVoiceId" to "jarvis_classic",
                    "customUserVoiceConsent" to false,
                    "wakeWordEnabled" to true,
                    "batteryAlertsEnabled" to true,
                    "preferredLanguage" to "auto",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    suspend fun updateUserPreferences(
        userId: String,
        preferredVoiceId: String? = null,
        customUserVoiceConsent: Boolean? = null,
        wakeWordEnabled: Boolean? = null,
        batteryAlertsEnabled: Boolean? = null,
        preferredLanguage: String? = null
    ) {
        val docRef = userDoc(userId)
        val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
        preferredVoiceId?.let { updates["preferredVoiceId"] = it.take(50) }
        customUserVoiceConsent?.let { updates["customUserVoiceConsent"] = it }
        wakeWordEnabled?.let { updates["wakeWordEnabled"] = it }
        batteryAlertsEnabled?.let { updates["batteryAlertsEnabled"] = it }
        preferredLanguage?.let { updates["preferredLanguage"] = it.take(30) }
        try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                ensureUserProfile(userId, auth.currentUser?.displayName ?: "Tony")
            }
            docRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    // --- Delete History & Activity Records (Permanent) ---

    fun observeDeleteRecords(userId: String): Flow<List<DeleteRecord>> =
        userDoc(userId).collection("deleteRecords")
            .orderBy("deletedAtEpochMs", Query.Direction.DESCENDING)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(DeleteRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            .catch { error ->
                logFlowErrorIfSignedIn(userId, error, OperationType.LIST, "users/$userId/deleteRecords")
                throw error
            }

    suspend fun addDeleteRecord(
        itemTitle: String,
        itemType: String,
        sourceApp: String,
        details: String,
        dateKey: String,
        deletedAtEpochMs: Long
    ): String {
        val uid = requireUserId()
        val id = "del_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = userDoc(uid).collection("deleteRecords").document(id)
        val payload = mapOf(
            "userId" to uid,
            "itemTitle" to itemTitle.ifBlank { "Untitled Item" }.take(160),
            "itemType" to itemType,
            "sourceApp" to sourceApp.ifBlank { "Device" }.take(80),
            "details" to details.take(500),
            "dateKey" to dateKey,
            "deletedAtEpochMs" to deletedAtEpochMs,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
            return id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateDeleteRecordDetails(record: DeleteRecord, newTitle: String, newDetails: String) {
        val uid = requireUserId()
        require(record.id.isNotBlank()) { "Record ID must not be blank" }
        val docRef = userDoc(uid).collection("deleteRecords").document(record.id)
        try {
            docRef.update(
                mapOf(
                    "itemTitle" to newTitle.ifBlank { record.itemTitle }.take(160),
                    "details" to newDetails.take(500),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    // --- Allowlist & Spam Contacts ---

    fun observeAllowlistContacts(userId: String): Flow<List<AllowlistContact>> =
        userDoc(userId).collection("allowlistContacts")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(AllowlistContact::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.name.lowercase() }
            }
            .catch { error ->
                logFlowErrorIfSignedIn(userId, error, OperationType.LIST, "users/$userId/allowlistContacts")
                throw error
            }

    suspend fun saveAllowlistContact(
        name: String,
        phoneNumber: String,
        relationship: String,
        isAllowlisted: Boolean,
        isBlockedSpam: Boolean
    ): String {
        val uid = requireUserId()
        val id = "cnt_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = userDoc(uid).collection("allowlistContacts").document(id)
        val payload = mapOf(
            "userId" to uid,
            "name" to name.ifBlank { "Contact" }.take(100),
            "phoneNumber" to phoneNumber.trim().take(30),
            "relationship" to relationship.take(60),
            "isAllowlisted" to isAllowlisted,
            "isBlockedSpam" to isBlockedSpam,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
            return id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateAllowlistStatus(contactId: String, isAllowlisted: Boolean, isBlockedSpam: Boolean) {
        val uid = requireUserId()
        val docRef = userDoc(uid).collection("allowlistContacts").document(contactId)
        try {
            docRef.update(
                mapOf(
                    "isAllowlisted" to isAllowlisted,
                    "isBlockedSpam" to isBlockedSpam,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteAllowlistContact(contactId: String) {
        val uid = requireUserId()
        val docRef = userDoc(uid).collection("allowlistContacts").document(contactId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // --- Social Reports ---

    fun observeSocialReports(userId: String): Flow<List<SocialReport>> =
        userDoc(userId).collection("socialReports")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(SocialReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.dateKey }
            }
            .catch { error ->
                logFlowErrorIfSignedIn(userId, error, OperationType.LIST, "users/$userId/socialReports")
                throw error
            }

    suspend fun saveSocialReport(report: SocialReport): String {
        val uid = requireUserId()
        val id = report.id.ifBlank { "soc_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
        val docRef = userDoc(uid).collection("socialReports").document(id)
        val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val payload = mapOf(
            "userId" to uid,
            "platform" to report.platform,
            "periodType" to report.periodType,
            "dateKey" to report.dateKey.ifBlank { todayKey }.take(10),
            "totalFollowers" to report.totalFollowers.coerceAtLeast(0L),
            "newFollowers" to report.newFollowers.coerceAtLeast(0L),
            "viewsOrImpressions" to report.viewsOrImpressions.coerceAtLeast(0L),
            "likes" to report.likes.coerceAtLeast(0L),
            "comments" to report.comments.coerceAtLeast(0L),
            "shares" to report.shares.coerceAtLeast(0L),
            "messagesCount" to report.messagesCount.coerceAtLeast(0L),
            "earningsInr" to report.earningsInr.coerceAtLeast(0.0),
            "dataSource" to report.dataSource.ifBlank { "Official Account Dashboard" }.take(120),
            "unfollowersNote" to report.unfollowersNote.take(250),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
            return id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteSocialReport(reportId: String) {
        val uid = requireUserId()
        val docRef = userDoc(uid).collection("socialReports").document(reportId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // --- SIM Plans ---

    fun observeSimPlans(userId: String): Flow<List<SimPlan>> =
        userDoc(userId).collection("simPlans")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(SimPlan::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.simSlot }
            }
            .catch { error ->
                logFlowErrorIfSignedIn(userId, error, OperationType.LIST, "users/$userId/simPlans")
                throw error
            }

    suspend fun saveSimPlan(plan: SimPlan): String {
        val uid = requireUserId()
        val slot = plan.simSlot.coerceIn(1, 2)
        val id = "sim_slot_$slot"
        val docRef = userDoc(uid).collection("simPlans").document(id)
        val defaultExpiry = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            .format(Date(System.currentTimeMillis() + 28L * 24L * 60L * 60L * 1000L))
        try {
            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(
                    mapOf(
                        "operatorName" to plan.operatorName.ifBlank { "Jio" }.take(40),
                        "planName" to plan.planName.ifBlank { "Active Plan" }.take(100),
                        "planPriceInr" to plan.planPriceInr.coerceAtLeast(0.0),
                        "remainingDataGb" to plan.remainingDataGb.coerceAtLeast(0.0),
                        "validityDays" to plan.validityDays.coerceAtLeast(0),
                        "expiryDateKey" to plan.expiryDateKey.ifBlank { defaultExpiry }.take(20),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                val payload = mapOf(
                    "userId" to uid,
                    "simSlot" to slot,
                    "operatorName" to plan.operatorName.ifBlank { "Jio" }.take(40),
                    "planName" to plan.planName.ifBlank { "Active Plan" }.take(100),
                    "planPriceInr" to plan.planPriceInr.coerceAtLeast(0.0),
                    "remainingDataGb" to plan.remainingDataGb.coerceAtLeast(0.0),
                    "validityDays" to plan.validityDays.coerceAtLeast(0),
                    "expiryDateKey" to plan.expiryDateKey.ifBlank { defaultExpiry }.take(20),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            }
            return id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    // --- Custom Voice Profiles ---

    fun observeVoiceProfiles(userId: String): Flow<List<VoiceProfile>> =
        userDoc(userId).collection("voiceProfiles")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(VoiceProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            .catch { error ->
                logFlowErrorIfSignedIn(userId, error, OperationType.LIST, "users/$userId/voiceProfiles")
                throw error
            }

    suspend fun addVoiceProfile(
        name: String,
        description: String,
        pitch: Double,
        speechRate: Double,
        isUserOwnVoice: Boolean,
        consentGranted: Boolean
    ): String {
        val uid = requireUserId()
        val id = "voice_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        val docRef = userDoc(uid).collection("voiceProfiles").document(id)
        val payload = mapOf(
            "userId" to uid,
            "name" to name.ifBlank { "Custom Voice" }.take(60),
            "description" to description.ifBlank { "User-configured style" }.take(160),
            "pitch" to pitch.coerceIn(0.4, 2.0),
            "speechRate" to speechRate.coerceIn(0.4, 2.0),
            "isUserOwnVoice" to isUserOwnVoice,
            "consentGranted" to consentGranted,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
            return id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    private fun logFlowErrorIfSignedIn(
        uid: String,
        error: Throwable,
        operationType: OperationType,
        path: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
    }
}
