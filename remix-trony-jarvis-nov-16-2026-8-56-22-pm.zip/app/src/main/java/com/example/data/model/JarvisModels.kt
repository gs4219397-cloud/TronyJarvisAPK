package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "Tony",
    val preferredVoiceId: String = "jarvis_classic",
    val customUserVoiceConsent: Boolean = false,
    val wakeWordEnabled: Boolean = true,
    val batteryAlertsEnabled: Boolean = true,
    val preferredLanguage: String = "auto",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class DeleteRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val itemTitle: String = "",
    val itemType: String = "photo", // photo, video, sms, music, movie, chat
    val sourceApp: String = "Gallery",
    val details: String = "",
    val dateKey: String = "", // YYYY-MM-DD
    val deletedAtEpochMs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AllowlistContact(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val phoneNumber: String = "",
    val relationship: String = "",
    val isAllowlisted: Boolean = true,
    val isBlockedSpam: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class SocialReport(
    @DocumentId val id: String = "",
    val userId: String = "",
    val platform: String = "facebook", // facebook, instagram, x, messenger
    val periodType: String = "daily", // daily, monthly, yearly
    val dateKey: String = "",
    val totalFollowers: Long = 0L,
    val newFollowers: Long = 0L,
    val viewsOrImpressions: Long = 0L,
    val likes: Long = 0L,
    val comments: Long = 0L,
    val shares: Long = 0L,
    val messagesCount: Long = 0L,
    val earningsInr: Double = 0.0,
    val dataSource: String = "Official Account Snapshot",
    val unfollowersNote: String = "Shown only when platform API provides unfollower data.",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class SimPlan(
    @DocumentId val id: String = "",
    val userId: String = "",
    val simSlot: Int = 1,
    val operatorName: String = "",
    val planName: String = "",
    val planPriceInr: Double = 0.0,
    val remainingDataGb: Double = 0.0,
    val validityDays: Int = 0,
    val expiryDateKey: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class VoiceProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val description: String = "",
    val pitch: Double = 1.0,
    val speechRate: Double = 1.0,
    val isUserOwnVoice: Boolean = false,
    val consentGranted: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class JarvisCoreState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

data class VoiceStylePreset(
    val id: String,
    val name: String,
    val subtitle: String,
    val pitch: Float,
    val speechRate: Float,
    val isUserOwnVoice: Boolean = false,
    val isCustomAdded: Boolean = false
)

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val languageHint: String = "auto",
    val timestampMs: Long = System.currentTimeMillis(),
    val isStreaming: Boolean = false
)

data class VisionAnalysisResult(
    val appearanceSummary: String,
    val beardAndMoustache: String,
    val hairstyle: String,
    val outfitAndColors: String,
    val observedExpression: String,
    val expressionDisclaimer: String,
    val moodCategory: String, // "upbeat" or "soothing"
    val musicSuggestionQuery: String,
    val musicReason: String
)

data class ShoppingProduct(
    val name: String,
    val platform: String,
    val priceInr: String,
    val rating: String,
    val seller: String,
    val ramStorage: String,
    val processor: String,
    val camera: String,
    val battery: String,
    val display: String,
    val deliveryAndTaxes: String,
    val searchUrl: String
)

data class MovieSearchResult(
    val title: String,
    val language: String,
    val year: String,
    val summary: String,
    val ottPlatforms: List<String>,
    val officialNote: String
)

data class TicketBookingOption(
    val bookingType: String, // Train, Movie, Flight/Bus
    val title: String,
    val dateText: String,
    val timeText: String,
    val seatInfo: String,
    val estimatedPriceInr: String,
    val officialPlatformName: String,
    val officialUrl: String
)

data class DeviceContact(
    val name: String,
    val phoneNumber: String
)

data class SimSlotInfo(
    val slotIndex: Int,
    val carrierName: String,
    val displayName: String,
    val countryIso: String,
    val isRoaming: Boolean
)

data class BatteryStatus(
    val percentage: Int = -1,
    val isCharging: Boolean = false,
    val pluggedSource: String = "Battery",
    val dropSinceSessionStart: Int = 0,
    val lastAnnouncement: String = ""
)

sealed interface PendingConfirmation {
    data class VoiceCall(val contactName: String, val phoneNumber: String) : PendingConfirmation
    data class SocialMessage(
        val platform: String,
        val recipient: String,
        val messageText: String
    ) : PendingConfirmation
    data class LocationShare(
        val latitude: Double,
        val longitude: Double,
        val recipient: String,
        val targetApp: String
    ) : PendingConfirmation
    data class DeleteItem(
        val title: String,
        val itemType: String,
        val sourceApp: String,
        val uriString: String? = null
    ) : PendingConfirmation
    data class ShoppingOrder(
        val product: ShoppingProduct,
        val deliveryAddress: String,
        val contactPhone: String,
        val paymentMethod: String,
        val finalPriceSummary: String
    ) : PendingConfirmation
    data class TicketBooking(
        val option: TicketBookingOption,
        val passengerOrGuestCount: Int
    ) : PendingConfirmation
}
