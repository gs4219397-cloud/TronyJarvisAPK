package com.example

import android.app.Activity
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.repository.JarvisAiRepository
import com.example.data.repository.JarvisFirestoreRepository
import com.example.system.PhoneCommsHelper
import com.example.system.authStateFlow
import com.example.system.configureAppCheck
import com.example.ui.components.PendingConfirmationDialog
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CommsScreen
import com.example.ui.screens.CoreScreen
import com.example.ui.screens.HubScreen
import com.example.ui.screens.RecordsScreen
import com.example.ui.screens.SystemScreen
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.DeepSpace
import com.example.ui.theme.HudSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TronyJarvisTheme
import com.example.ui.theme.VoidBlack
import com.example.ui.viewmodel.JarvisViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

sealed class JarvisDestination(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    data object Core : JarvisDestination("core", "Core", Icons.Default.Hub)
    data object Comms : JarvisDestination("comms", "Comms", Icons.Default.Call)
    data object Hub : JarvisDestination("hub", "Hub", Icons.Default.Apps)
    data object Records : JarvisDestination("records", "Records", Icons.Default.History)
    data object System : JarvisDestination("system", "System", Icons.Default.Settings)
}

private val JARVIS_DESTINATIONS = listOf(
    JarvisDestination.Core,
    JarvisDestination.Comms,
    JarvisDestination.Hub,
    JarvisDestination.Records,
    JarvisDestination.System
)

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent BEFORE UI or ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            TronyJarvisTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            JarvisMainShell(
                currentUserId = user.uid,
                userDisplayName = user.displayName ?: "Tony"
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisMainShell(
    currentUserId: String,
    userDisplayName: String
) {
    val context = LocalContext.current
    val viewModel: JarvisViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                JarvisViewModel(
                    firestoreRepo = JarvisFirestoreRepository(db),
                    aiRepo = JarvisAiRepository(),
                    currentUserId = currentUserId,
                    userDisplayName = userDisplayName
                )
            }
        }
    )

    LaunchedEffect(Unit) {
        viewModel.attachHardwareEngines(context.applicationContext)
    }

    val pendingConfirmation by viewModel.pendingConfirmation.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val pendingMediaDelete by viewModel.pendingMediaDeleteUri.collectAsStateWithLifecycle()
    val unlockPromptTrigger by viewModel.unlockPromptTrigger.collectAsStateWithLifecycle()

    LaunchedEffect(unlockPromptTrigger) {
        if (unlockPromptTrigger) {
            viewModel.consumeUnlockPrompt()
            val activity = context as? FragmentActivity
            if (activity != null) {
                PhoneCommsHelper.promptSecureBiometricUnlock(
                    activity = activity,
                    onAuthenticated = { viewModel.onUnlockCompleted(success = true) },
                    onError = { err -> viewModel.onUnlockCompleted(success = false, errorMessage = err) }
                )
            }
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(statusBanner) {
        statusBanner?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearBanner()
        }
    }

    val mediaDeleteLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.speakOut("Selected media item deleted.")
        }
        viewModel.clearPendingMediaDeleteIntent()
    }

    LaunchedEffect(pendingMediaDelete) {
        val pair = pendingMediaDelete ?: return@LaunchedEffect
        val pi = PhoneCommsHelper.buildMediaDeletePendingIntent(context, pair.first)
        if (pi != null) {
            mediaDeleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            viewModel.clearPendingMediaDeleteIntent()
        }
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val navigateTo: (JarvisDestination) -> Unit = { dest ->
        navController.navigate(dest.route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(VoidBlack, DeepSpace, VoidBlack)))
    ) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "TRONY AI JARVIS",
                                style = MaterialTheme.typography.headlineSmall,
                                color = ArcCyan
                            )
                            Text(
                                text = "HOLOGRAPHIC ASSISTANT // ${userDisplayName.uppercase()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = HudSurface.copy(alpha = 0.85f)
                    )
                )
            },
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar(
                        containerColor = HudSurface,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        JARVIS_DESTINATIONS.forEach { dest ->
                            val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(dest) },
                                icon = { Icon(dest.icon, contentDescription = dest.label) },
                                label = { Text(dest.label, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("nav_${dest.route}"),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = VoidBlack,
                                    selectedTextColor = ArcCyan,
                                    indicatorColor = ArcCyan,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail(containerColor = HudSurface) {
                        JARVIS_DESTINATIONS.forEach { dest ->
                            val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(dest) },
                                icon = { Icon(dest.icon, contentDescription = dest.label) },
                                label = { Text(dest.label) }
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = JarvisDestination.Core.route,
                        modifier = Modifier.widthIn(max = 860.dp).fillMaxSize()
                    ) {
                        composable(JarvisDestination.Core.route) { CoreScreen(viewModel) }
                        composable(JarvisDestination.Comms.route) { CommsScreen(viewModel) }
                        composable(JarvisDestination.Hub.route) { HubScreen(viewModel) }
                        composable(JarvisDestination.Records.route) { RecordsScreen(viewModel) }
                        composable(JarvisDestination.System.route) {
                            SystemScreen(
                                viewModel = viewModel,
                                onSignedOut = {}
                            )
                        }
                    }
                }
            }
        }
    }

    pendingConfirmation?.let { pending ->
        PendingConfirmationDialog(
            pending = pending,
            onConfirm = { viewModel.confirmPendingAction(context) },
            onDismiss = { viewModel.dismissPendingAction() }
        )
    }
}
