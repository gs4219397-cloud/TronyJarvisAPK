package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DeleteRecord
import com.example.ui.components.HudCard
import com.example.ui.components.HudSectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.NominalGreen
import com.example.ui.theme.StarkAmber
import com.example.ui.theme.VoidBlack
import com.example.ui.viewmodel.JarvisViewModel
import com.example.ui.viewmodel.StreamState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RecordsScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val recordsState by viewModel.deleteRecordsState.collectAsStateWithLifecycle()

    var selectedDaysWindow by remember { mutableStateOf(3650) } // 1, 8, 30, 365, 3650(all)
    var selectedTypeFilter by remember { mutableStateOf("all") }
    var showLogDialog by remember { mutableStateOf(false) }
    var editingRecord by remember { mutableStateOf<DeleteRecord?>(null) }

    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            var displayName = "Selected Gallery Item"
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) displayName = c.getString(idx) ?: displayName
                }
            }
            val mime = context.contentResolver.getType(uri).orEmpty()
            val itemType = if (mime.startsWith("video")) "video" else "photo"
            viewModel.requestMediaDeletionWithConfirmation(
                title = displayName,
                itemType = itemType,
                sourceApp = "Gallery",
                uri = uri
            )
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            HudSectionHeader(
                title = "Permanent Delete History",
                subtitle = "Non-expiring activity log & confirmed Gallery deletion control",
                icon = Icons.Default.History
            )
        }

        // Gallery & Media Deletion Control
        item {
            HudCard(borderColor = ArcCyan.copy(alpha = 0.6f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Gallery & Message Control", style = MaterialTheme.typography.titleMedium, color = ArcCyan)
                    StatusPill(label = "CONFIRMATION LOCKED", color = NominalGreen)
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Select a photo or video via Android Photo Picker to preview and delete with confirmation. Note: Android restricts silent background deletion and restricts third-party apps from deleting system SMS unless set as the default SMS app. Records here are permanent activity logs, not media backups.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            mediaPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                            )
                        },
                        modifier = Modifier.weight(1f).testTag("pick_media_delete_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = VoidBlack)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Pick & Delete Media")
                    }
                    OutlinedButton(
                        onClick = { showLogDialog = true },
                        modifier = Modifier.weight(1f).testTag("log_manual_delete_button")
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Log SMS/File")
                    }
                }
            }
        }

        // Time Window Filters: 1 Day, 8 Days, 1 Month, 1 Year, All
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Period Filter", style = MaterialTheme.typography.labelMedium, color = ArcCyan)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        1 to "1 Day",
                        8 to "8 Days",
                        30 to "1 Month",
                        365 to "1 Year",
                        3650 to "All Permanent"
                    ).forEach { (days, label) ->
                        FilterChip(
                            selected = selectedDaysWindow == days,
                            onClick = { selectedDaysWindow = days },
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("all", "photo", "video", "sms", "music", "movie", "chat").forEach { type ->
                        FilterChip(
                            selected = selectedTypeFilter == type,
                            onClick = { selectedTypeFilter = type },
                            label = { Text(type.uppercase(), style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        }

        when (val state = recordsState) {
            is StreamState.Loading -> {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(20.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = ArcCyan)
                    }
                }
            }
            is StreamState.Error -> {
                item { Text("Error loading records: ${state.message}", color = AlertRed) }
            }
            is StreamState.Success -> {
                val cutoff = if (selectedDaysWindow >= 3650) 0L else {
                    System.currentTimeMillis() - selectedDaysWindow * 24L * 60L * 60L * 1000L
                }
                val filtered = state.data.filter { rec ->
                    val inTime = rec.deletedAtEpochMs >= cutoff
                    val inType = selectedTypeFilter == "all" || rec.itemType == selectedTypeFilter
                    inTime && inType
                }

                // Per-date counts
                val countsByDate = filtered.groupingBy { it.dateKey }.eachCount()
                if (countsByDate.isNotEmpty()) {
                    item {
                        HudCard(borderColor = StarkAmber.copy(alpha = 0.5f)) {
                            Text(
                                text = "Deleted Items Count Per Date (${filtered.size} total)",
                                style = MaterialTheme.typography.titleMedium,
                                color = StarkAmber
                            )
                            Spacer(Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                countsByDate.entries.take(15).forEach { (date, count) ->
                                    StatusPill(label = "$date: $count", color = ArcCyan)
                                }
                            }
                        }
                    }
                }

                if (filtered.isEmpty()) {
                    item {
                        HudCard {
                            Text(
                                text = "No deletion activity records for this period.",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    items(filtered, key = { it.id }) { rec ->
                        val timeFormatted = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                            .format(Date(rec.deletedAtEpochMs))
                        HudCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.DeleteForever,
                                            contentDescription = null,
                                            tint = StarkAmber,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(rec.itemTitle, style = MaterialTheme.typography.titleMedium)
                                    }
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = "${rec.itemType.uppercase()} • ${rec.sourceApp} • $timeFormatted",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ArcCyan
                                    )
                                    if (rec.details.isNotBlank()) {
                                        Spacer(Modifier.height(4.dp))
                                        Text(
                                            text = rec.details,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                IconButton(onClick = { editingRecord = rec }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Update record note", tint = ArcCyan)
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }

    if (showLogDialog) {
        var title by remember { mutableStateOf("") }
        var type by remember { mutableStateOf("sms") }
        var source by remember { mutableStateOf("Messages") }
        var details by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showLogDialog = false },
            title = { Text("Log Deletion Activity") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Item Title") })
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("photo", "video", "sms", "music", "movie", "chat").forEach { t ->
                            FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) })
                        }
                    }
                    OutlinedTextField(value = source, onValueChange = { source = it }, label = { Text("Source App") })
                    OutlinedTextField(value = details, onValueChange = { details = it }, label = { Text("Details / Note") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.logManualDeleteRecord(title, type, source, details)
                        showLogDialog = false
                    },
                    enabled = title.isNotBlank()
                ) { Text("Save Permanently") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showLogDialog = false }) { Text("Cancel") }
            }
        )
    }

    editingRecord?.let { rec ->
        var newTitle by remember(rec.id) { mutableStateOf(rec.itemTitle) }
        var newDetails by remember(rec.id) { mutableStateOf(rec.details) }

        AlertDialog(
            onDismissRequest = { editingRecord = null },
            title = { Text("Update Permanent Record") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = newTitle, onValueChange = { newTitle = it }, label = { Text("Item Title") })
                    OutlinedTextField(value = newDetails, onValueChange = { newDetails = it }, label = { Text("Details") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.updateOldDeleteRecord(rec, newTitle, newDetails)
                    editingRecord = null
                }) { Text("Update") }
            },
            dismissButton = {
                OutlinedButton(onClick = { editingRecord = null }) { Text("Cancel") }
            }
        )
    }
}
