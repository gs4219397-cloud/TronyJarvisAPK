package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.PendingConfirmation
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.HudBorder
import com.example.ui.theme.HudSurface
import com.example.ui.theme.HudSurfaceElevated
import com.example.ui.theme.NominalGreen
import com.example.ui.theme.StarkAmber
import com.example.ui.theme.VoidBlack

@Composable
fun HudCard(
    modifier: Modifier = Modifier,
    borderColor: Color = HudBorder,
    containerColor: Color = HudSurface,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun HudSectionHeader(
    title: String,
    subtitle: String? = null,
    icon: ImageVector? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = ArcCyan,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
        }
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun StatusPill(
    label: String,
    color: Color = ArcCyan,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.55f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .background(color, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = color
            )
        }
    }
}

@Composable
fun PendingConfirmationDialog(
    pending: PendingConfirmation,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val (title, body, confirmLabel) = when (pending) {
        is PendingConfirmation.VoiceCall -> Triple(
            "Confirm Voice Call",
            "Target: ${pending.contactName}\nNumber: ${pending.phoneNumber}\n\nProceed to place this call?",
            "Call Now"
        )
        is PendingConfirmation.SocialMessage -> Triple(
            "Confirm ${pending.platform} Message",
            "Recipient: ${pending.recipient.ifBlank { "Select in ${pending.platform}" }}\n\nMessage:\n\"${pending.messageText}\"\n\nक्या इसे भेज दूँ? (Shall I send this?)",
            "Yes, Send"
        )
        is PendingConfirmation.LocationShare -> Triple(
            "Confirm Live Location Share",
            "Coordinates: ${"%.5f".format(pending.latitude)}, ${"%.5f".format(pending.longitude)}\nRecipient: ${pending.recipient}\nApp: ${pending.targetApp}\n\nShare your live location now?",
            "Share Location"
        )
        is PendingConfirmation.DeleteItem -> Triple(
            "Confirm Deletion",
            "Item: ${pending.title}\nType: ${pending.itemType.uppercase()}\nSource: ${pending.sourceApp}\n\nThis will trigger deletion and record a permanent entry in Delete History. Proceed?",
            "Delete & Log"
        )
        is PendingConfirmation.ShoppingOrder -> Triple(
            "Confirm Order Handoff",
            "Product: ${pending.product.name}\nPlatform: ${pending.product.platform}\nFinal Summary: ${pending.finalPriceSummary}\nDelivery: ${pending.deliveryAddress}\nPayment: ${pending.paymentMethod}\n\nNote: Enter PIN, CVV, or OTP only on the official ${pending.product.platform} payment page.",
            "Open Official Checkout"
        )
        is PendingConfirmation.TicketBooking -> Triple(
            "Confirm Ticket Booking",
            "Type: ${pending.option.bookingType}\nTitle: ${pending.option.title}\nDate & Time: ${pending.option.dateText} • ${pending.option.timeText}\nSeat/Class: ${pending.option.seatInfo}\nGuests/Passengers: ${pending.passengerOrGuestCount}\nEst. Price: ${pending.option.estimatedPriceInr}\n\nProceed to official ${pending.option.officialPlatformName} booking?",
            "Proceed to ${pending.option.officialPlatformName}"
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = HudSurfaceElevated,
        titleContentColor = ArcCyan,
        textContentColor = MaterialTheme.colorScheme.onSurface,
        icon = {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = "Security confirmation",
                tint = StarkAmber
            )
        },
        title = {
            Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        },
        text = {
            Text(text = body, style = MaterialTheme.typography.bodyLarge)
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                modifier = Modifier.testTag("confirm_action_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NominalGreen,
                    contentColor = VoidBlack
                )
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(confirmLabel)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_action_button")
            ) {
                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Cancel")
            }
        }
    )
}
