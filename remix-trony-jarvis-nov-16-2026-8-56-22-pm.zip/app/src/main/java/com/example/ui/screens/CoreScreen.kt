package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.JarvisCoreState
import com.example.system.PhoneCommsHelper
import com.example.ui.components.JarvisArcCore
import com.example.ui.components.StatusPill
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.HoloBlue
import com.example.ui.theme.HudBorder
import com.example.ui.theme.HudSurface
import com.example.ui.theme.HudSurfaceElevated
import com.example.ui.theme.NominalGreen
import com.example.ui.theme.StarkAmber
import com.example.ui.theme.VoidBlack
import com.example.ui.viewmodel.JarvisViewModel

@Composable
fun CoreScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coreState by viewModel.coreState.collectAsStateWithLifecycle()
    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val partialSpeech by viewModel.partialSpeech.collectAsStateWithLifecycle()
    val battery by viewModel.batteryStatus.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val voicePresets by viewModel.allVoicePresets.collectAsStateWithLifecycle()

    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.startVoiceListening(wakeWordMode = userProfile?.wakeWordEnabled ?: false)
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val activeVoice = voicePresets.firstOrNull { it.id == userProfile?.preferredVoiceId }
        ?: voicePresets.first()
    val preferredLang = userProfile?.preferredLanguage ?: "auto"
    val wakeEnabled = userProfile?.wakeWordEnabled ?: true

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Telemetry strip
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusPill(
                label = "VOICE: ${activeVoice.name.uppercase().take(16)}",
                color = ArcCyan
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (battery.percentage >= 0) {
                    StatusPill(
                        label = "${battery.percentage}%",
                        color = if (battery.percentage <= 20) StarkAmber else NominalGreen
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Icon(
                    imageVector = Icons.Default.BatteryChargingFull,
                    contentDescription = "Battery telemetry",
                    tint = if (battery.isCharging) NominalGreen else ArcCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        // Arc Reactor & Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            JarvisArcCore(
                state = coreState,
                size = 172.dp
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FloatingActionButton(
                    onClick = {
                        when (coreState) {
                            JarvisCoreState.LISTENING -> viewModel.stopVoiceListening()
                            JarvisCoreState.SPEAKING -> viewModel.stopSpeaking()
                            else -> {
                                if (PhoneCommsHelper.hasPermission(context, Manifest.permission.RECORD_AUDIO)) {
                                    viewModel.startVoiceListening(wakeWordMode = wakeEnabled)
                                } else {
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        }
                    },
                    shape = CircleShape,
                    containerColor = when (coreState) {
                        JarvisCoreState.LISTENING -> NominalGreen
                        JarvisCoreState.SPEAKING -> StarkAmber
                        else -> ArcCyan
                    },
                    contentColor = VoidBlack,
                    modifier = Modifier
                        .size(64.dp)
                        .testTag("mic_button")
                ) {
                    Icon(
                        imageVector = when (coreState) {
                            JarvisCoreState.LISTENING -> Icons.Default.GraphicEq
                            JarvisCoreState.SPEAKING -> Icons.Default.Stop
                            else -> Icons.Default.Mic
                        },
                        contentDescription = "Activate Jarvis Voice",
                        modifier = Modifier.size(30.dp)
                    )
                }

                Text(
                    text = when (coreState) {
                        JarvisCoreState.LISTENING -> "Listening..."
                        JarvisCoreState.THINKING -> "Thinking..."
                        JarvisCoreState.SPEAKING -> "Tap to Mute"
                        JarvisCoreState.IDLE -> "Tap to Speak"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = ArcCyan
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Hi JARVIS",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(6.dp))
                    Switch(
                        checked = wakeEnabled,
                        onCheckedChange = { viewModel.updatePreferences(wakeWordEnabled = it) }
                    )
                }
            }
        }

        if (partialSpeech.isNotBlank()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(10.dp),
                color = NominalGreen.copy(alpha = 0.12f),
                border = BorderStroke(1.dp, NominalGreen.copy(alpha = 0.4f))
            ) {
                Text(
                    text = "Hearing: $partialSpeech",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NominalGreen,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }

        // Language chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "auto" to "Auto Multi",
                "hi" to "हिन्दी",
                "bn" to "বাংলা",
                "ta" to "தமிழ்",
                "en" to "English"
            ).forEach { (code, label) ->
                FilterChip(
                    selected = preferredLang == code,
                    onClick = { viewModel.updatePreferences(preferredLanguage = code) },
                    label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ArcCyan.copy(alpha = 0.22f),
                        selectedLabelColor = ArcCyan
                    )
                )
            }
        }

        // Quick voice command chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "Hi JARVIS, तुम कैसे हो?",
                "Tony JARVIS, मेरी live location भेज दो",
                "Battery status बताओ",
                "₹20,000 के अंदर phone खोजो",
                "Social report का हिसाब बताओ",
                "Tony AI JARVIS, lock कर दो"
            ).forEach { cmd ->
                AssistChip(
                    onClick = { viewModel.submitUserQuery(context, cmd) },
                    label = { Text(cmd, style = MaterialTheme.typography.labelSmall) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = HudSurface,
                        labelColor = HoloBlue
                    ),
                    border = BorderStroke(1.dp, HudBorder)
                )
            }
        }

        Spacer(Modifier.height(6.dp))

        // Conversational HUD Feed
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                val alignEnd = msg.isUser
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = if (alignEnd) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (alignEnd) HudSurfaceElevated else HudSurface,
                        border = BorderStroke(
                            1.dp,
                            if (alignEnd) HoloBlue.copy(alpha = 0.6f) else ArcCyan.copy(alpha = 0.45f)
                        ),
                        modifier = Modifier.fillMaxWidth(0.90f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (alignEnd) "YOU" else "TRONY AI JARVIS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (alignEnd) HoloBlue else ArcCyan
                                )
                                if (!alignEnd && msg.text.isNotBlank() && !msg.isStreaming) {
                                    IconButton(
                                        onClick = { viewModel.speakOut(msg.text) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.RecordVoiceOver,
                                            contentDescription = "Speak reply",
                                            tint = ArcCyan,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = if (msg.isStreaming && msg.text.isBlank()) "Synthesizing response..." else msg.text,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(6.dp))

        // Text Input Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Speak or type in any language...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_field"),
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ArcCyan,
                    unfocusedBorderColor = HudBorder,
                    focusedContainerColor = HudSurface,
                    unfocusedContainerColor = HudSurface
                )
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = {
                    val toSend = inputText.trim()
                    if (toSend.isNotEmpty()) {
                        inputText = ""
                        viewModel.submitUserQuery(context, toSend)
                    }
                },
                modifier = Modifier
                    .size(50.dp)
                    .background(ArcCyan, CircleShape)
                    .testTag("send_chat_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send command",
                    tint = VoidBlack
                )
            }
        }
    }
}
