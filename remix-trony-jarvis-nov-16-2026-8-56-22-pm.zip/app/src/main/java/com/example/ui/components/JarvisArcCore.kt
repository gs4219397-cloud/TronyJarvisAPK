package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.JarvisCoreState
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.HoloBlue
import com.example.ui.theme.NominalGreen
import com.example.ui.theme.StarkAmber
import com.example.ui.theme.StarkCobalt
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisArcCore(
    state: JarvisCoreState,
    modifier: Modifier = Modifier,
    size: Dp = 210.dp
) {
    val transition = rememberInfiniteTransition(label = "jarvis_core")

    val slowRotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    JarvisCoreState.THINKING -> 2200
                    JarvisCoreState.SPEAKING -> 4500
                    JarvisCoreState.LISTENING -> 6000
                    JarvisCoreState.IDLE -> 14000
                },
                easing = LinearEasing
            )
        ),
        label = "slow_rot"
    )

    val counterRotation by transition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    JarvisCoreState.THINKING -> 1600
                    JarvisCoreState.SPEAKING -> 3200
                    JarvisCoreState.LISTENING -> 4200
                    JarvisCoreState.IDLE -> 9500
                },
                easing = LinearEasing
            )
        ),
        label = "counter_rot"
    )

    val pulse by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    JarvisCoreState.LISTENING -> 650
                    JarvisCoreState.SPEAKING -> 420
                    JarvisCoreState.THINKING -> 550
                    JarvisCoreState.IDLE -> 1800
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val rippleProgress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing)
        ),
        label = "ripple"
    )

    val primaryGlow = when (state) {
        JarvisCoreState.IDLE -> ArcCyan
        JarvisCoreState.LISTENING -> NominalGreen
        JarvisCoreState.THINKING -> StarkAmber
        JarvisCoreState.SPEAKING -> HoloBlue
    }

    val stateLabel = when (state) {
        JarvisCoreState.IDLE -> "STANDBY"
        JarvisCoreState.LISTENING -> "LISTENING"
        JarvisCoreState.THINKING -> "PROCESSING"
        JarvisCoreState.SPEAKING -> "SPEAKING"
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val maxRadius = this.size.minDimension / 2f

            // Ambient radial reactor aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryGlow.copy(alpha = 0.28f),
                        StarkCobalt.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = maxRadius * pulse.coerceAtMost(1.1f)
                ),
                radius = maxRadius,
                center = center
            )

            // Listening acoustic ripple ring
            if (state == JarvisCoreState.LISTENING || state == JarvisCoreState.SPEAKING) {
                val r = maxRadius * (0.45f + 0.52f * rippleProgress)
                drawCircle(
                    color = primaryGlow.copy(alpha = (1f - rippleProgress) * 0.65f),
                    radius = r,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
            }

            // Outer segmented telemetry ring
            rotate(slowRotation, pivot = center) {
                val rOuter = maxRadius * 0.88f
                val arcSize = Size(rOuter * 2, rOuter * 2)
                val topLeft = Offset(center.x - rOuter, center.y - rOuter)
                for (i in 0 until 4) {
                    drawArc(
                        color = primaryGlow.copy(alpha = 0.85f),
                        startAngle = i * 90f + 10f,
                        sweepAngle = 62f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // Counter-rotating inner tactical ring
            rotate(counterRotation, pivot = center) {
                val rMid = maxRadius * 0.68f
                val arcSize = Size(rMid * 2, rMid * 2)
                val topLeft = Offset(center.x - rMid, center.y - rMid)
                for (i in 0 until 6) {
                    drawArc(
                        color = if (state == JarvisCoreState.THINKING && i % 2 == 0) StarkAmber else ArcCyan,
                        startAngle = i * 60f + 6f,
                        sweepAngle = 36f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // Speaking or Thinking harmonic radial ticks
            val tickCount = 24
            val baseTickRadius = maxRadius * 0.50f
            for (i in 0 until tickCount) {
                val angleRad = (i * (360.0 / tickCount) + slowRotation * 0.5) * PI / 180.0
                val amp = when (state) {
                    JarvisCoreState.SPEAKING -> 10.dp.toPx() * (0.4f + 0.6f * kotlin.math.abs(sin(angleRad * 3 + rippleProgress * 2 * PI).toFloat()))
                    JarvisCoreState.LISTENING -> 8.dp.toPx() * (0.3f + 0.7f * kotlin.math.abs(cos(angleRad * 2 + rippleProgress * 2 * PI).toFloat()))
                    JarvisCoreState.THINKING -> if (i % 3 == 0) 9.dp.toPx() else 3.dp.toPx()
                    JarvisCoreState.IDLE -> 3.dp.toPx()
                }
                val start = Offset(
                    x = center.x + (baseTickRadius * cos(angleRad)).toFloat(),
                    y = center.y + (baseTickRadius * sin(angleRad)).toFloat()
                )
                val end = Offset(
                    x = center.x + ((baseTickRadius + amp) * cos(angleRad)).toFloat(),
                    y = center.y + ((baseTickRadius + amp) * sin(angleRad)).toFloat()
                )
                drawLine(
                    color = primaryGlow.copy(alpha = 0.85f),
                    start = start,
                    end = end,
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // Inner reactor core circle
            drawCircle(
                color = primaryGlow.copy(alpha = 0.25f),
                radius = maxRadius * 0.36f * pulse,
                center = center
            )
            drawCircle(
                color = primaryGlow,
                radius = maxRadius * 0.34f,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "J.A.R.V.I.S",
                style = MaterialTheme.typography.labelMedium,
                color = primaryGlow
            )
            Text(
                text = stateLabel,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
