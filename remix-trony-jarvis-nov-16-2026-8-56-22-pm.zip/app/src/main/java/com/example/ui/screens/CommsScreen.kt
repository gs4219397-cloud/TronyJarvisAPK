package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.system.PhoneCommsHelper
import com.example.ui.components.HudCard
import com.example.ui.components.HudSectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.NominalGreen
import com.example.ui.theme.StarkAmber
import com.example.ui.theme.VoidBlack
import com.example.ui.viewmodel.JarvisViewModel
import com.example.ui.viewmodel.StreamState

@Composable
fun CommsScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val contacts by viewModel.deviceContacts.collectAsStateWithLifecycle()
    val allowlistState by viewModel.allowlistState.collectAsStateWithLifecycle()

    var callQuery by remember { mutableStateOf("") }
    var incomingTestNumber by remember { mutableStateOf("") }

    var allowName by remember { mutableStateOf("") }
    var allowPhone by remember { mutableStateOf("") }
    var allowRelation by remember { mutableStateOf("") }

    var selectedPlatform by remember { mutableStateOf("WhatsApp") }
    var msgRecipient by remember { mutableStateOf("") }
    var msgDraft by remember { mutableStateOf("") }

    var locRecipient by remember { mutableStateOf("") }
    var locApp by remember { mutableStateOf("WhatsApp") }

    val callPermsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.refreshHardwareTelemetry(context)
    }

    val locationPermsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            viewModel.requestLiveLocationShare(context, locRecipient, locApp)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            HudSectionHeader(
                title = "Voice Calling & Shield",
                subtitle = "Confirmed dialing, caller announcement, allowlist & spam defense",
                icon = Icons.Default.Call
            )
        }

        // Dial / Contact Calling
        item {
            HudCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Call by Name or Number", style = MaterialTheme.typography.titleMedium, color = ArcCyan)
                    OutlinedButton(onClick = {
                        callPermsLauncher.launch(
                            arrayOf(
                                Manifest.permission.READ_CONTACTS,
                                Manifest.permission.CALL_PHONE,
                                Manifest.permission.SEND_SMS
                            )
                        )
                    }) {
                        Icon(Icons.Default.Contacts, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Sync Contacts")
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = callQuery,
                    onValueChange = { callQuery = it },
                    label = { Text("Contact name or phone number") },
                    modifier = Modifier.fillMaxWidth().testTag("call_target_input"),
                    singleLine = true
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { viewModel.prepareVoiceCall(context, callQuery) },
                        enabled = callQuery.isNotBlank(),
                        modifier = Modifier.weight(1f).testTag("prepare_call_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = VoidBlack)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Review & Call")
                    }
                    OutlinedButton(
                        onClick = {
                            val digits = callQuery.filter { it.isDigit() || it == '+' }
                            PhoneCommsHelper.openDialerWithNumber(context, digits)
                        },
                        enabled = callQuery.any { it.isDigit() },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Dialpad, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Write in Dialer")
                    }
                }

                if (contacts.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text("Device Contacts (${contacts.size} loaded)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        contacts.take(10).forEach { c ->
                            FilterChip(
                                selected = false,
                                onClick = { callQuery = c.name },
                                label = { Text("${c.name} (${c.phoneNumber})", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
            }
        }

        // Caller Announcement & Call Screening
        item {
            HudCard(borderColor = StarkAmber.copy(alpha = 0.6f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Incoming Caller Announcement & Screening", style = MaterialTheme.typography.titleMedium, color = StarkAmber)
                    StatusPill(label = "CALL SCREENING READY", color = NominalGreen)
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Android's CallScreeningService filters spam numbers using your allowlist. Note: Android OS blocks third-party apps from injecting live AI voice into active cellular call audio unless speakerphone/system dialer APIs are used.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = incomingTestNumber,
                    onValueChange = { incomingTestNumber = it },
                    label = { Text("Test caller announcement (enter phone number)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { viewModel.announceIncomingCallerDemo(context, incomingTestNumber) },
                        enabled = incomingTestNumber.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.PhoneInTalk, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Announce Caller")
                    }
                    OutlinedButton(
                        onClick = { PhoneCommsHelper.openCallScreeningSettings(context) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Default Spam App")
                    }
                }
            }
        }

        // Trusted Allowlist & Spam List
        item {
            HudCard {
                Text("Trusted Allowlist & Spam Blocklist", style = MaterialTheme.typography.titleMedium, color = ArcCyan)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = allowName,
                    onValueChange = { allowName = it },
                    label = { Text("Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = allowPhone,
                        onValueChange = { allowPhone = it },
                        label = { Text("Phone Number") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = allowRelation,
                        onValueChange = { allowRelation = it },
                        label = { Text("Label (e.g. Family)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            viewModel.addAllowlistEntry(allowName, allowPhone, allowRelation, isBlockedSpam = false)
                            allowName = ""; allowPhone = ""; allowRelation = ""
                        },
                        enabled = allowName.isNotBlank() && allowPhone.length >= 3,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = NominalGreen, contentColor = VoidBlack)
                    ) {
                        Text("Add Allowlist")
                    }
                    OutlinedButton(
                        onClick = {
                            viewModel.addAllowlistEntry(allowName, allowPhone, allowRelation.ifBlank { "Spam" }, isBlockedSpam = true)
                            allowName = ""; allowPhone = ""; allowRelation = ""
                        },
                        enabled = allowName.isNotBlank() && allowPhone.length >= 3,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Block, contentDescription = null, tint = AlertRed, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Block Spam", color = AlertRed)
                    }
                }
            }
        }

        when (val state = allowlistState) {
            is StreamState.Success -> {
                items(state.data, key = { it.id }) { item ->
                    HudCard(
                        borderColor = if (item.isBlockedSpam) AlertRed.copy(alpha = 0.7f) else NominalGreen.copy(alpha = 0.6f)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${item.name} (${item.phoneNumber})", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = if (item.isBlockedSpam) "SPAM BLOCKED • ${item.relationship}" else "ALLOWLISTED • ${item.relationship}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (item.isBlockedSpam) AlertRed else NominalGreen
                                )
                            }
                            Row {
                                IconButton(onClick = { viewModel.toggleAllowlistSpam(item, !item.isBlockedSpam) }) {
                                    Icon(Icons.Default.Shield, contentDescription = "Toggle allowlist or spam", tint = StarkAmber)
                                }
                                IconButton(onClick = { viewModel.deleteAllowlistEntry(item.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete entry", tint = AlertRed)
                                }
                            }
                        }
                    }
                }
            }
            is StreamState.Error -> {
                item { Text("Allowlist error: ${state.message}", color = AlertRed) }
            }
            StreamState.Loading -> Unit
        }

        // Social Messaging Composer
        item {
            HudSectionHeader(
                title = "SMS & Social Messaging",
                subtitle = "Reads back message and asks 'क्या इसे भेज दूँ?' before sending",
                icon = Icons.AutoMirrored.Filled.Message
            )
            HudCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("WhatsApp", "SMS", "Messenger", "Facebook", "Instagram", "X").forEach { plat ->
                        FilterChip(
                            selected = selectedPlatform == plat,
                            onClick = { selectedPlatform = plat },
                            label = { Text(plat, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = msgRecipient,
                    onValueChange = { msgRecipient = it },
                    label = { Text("Recipient phone or handle (required for SMS)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = msgDraft,
                    onValueChange = { msgDraft = it },
                    label = { Text("Message content") },
                    modifier = Modifier.fillMaxWidth().testTag("social_message_input"),
                    minLines = 2
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { viewModel.prepareSocialMessage(selectedPlatform, msgRecipient, msgDraft) },
                    enabled = msgDraft.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().testTag("read_and_confirm_msg_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = VoidBlack)
                ) {
                    Icon(Icons.Default.RecordVoiceOver, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Read Aloud & Ask Confirmation")
                }
            }
        }

        // Live Location Sharing
        item {
            HudSectionHeader(
                title = "Live Location Sharing",
                subtitle = "GPS location shared only after recipient & app confirmation",
                icon = Icons.Default.LocationOn
            )
            HudCard {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = locRecipient,
                        onValueChange = { locRecipient = it },
                        label = { Text("Contact / Number") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = locApp,
                        onValueChange = { locApp = it },
                        label = { Text("App (WhatsApp / SMS)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (PhoneCommsHelper.hasPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ||
                            PhoneCommsHelper.hasPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
                        ) {
                            viewModel.requestLiveLocationShare(context, locRecipient, locApp)
                        } else {
                            locationPermsLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_COARSE_LOCATION,
                                    Manifest.permission.ACCESS_FINE_LOCATION
                                )
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("share_location_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = NominalGreen, contentColor = VoidBlack)
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Fetch GPS & Confirm Share")
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}
