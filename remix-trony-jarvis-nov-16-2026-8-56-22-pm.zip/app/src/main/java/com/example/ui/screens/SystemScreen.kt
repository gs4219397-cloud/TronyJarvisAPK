package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.SimPlan
import com.example.system.PhoneCommsHelper
import com.example.system.signOutJarvis
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.example.ui.components.HudCard
import com.example.ui.components.HudSectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.HudBorder
import com.example.ui.theme.NominalGreen
import com.example.ui.theme.StarkAmber
import com.example.ui.theme.VoidBlack
import com.example.ui.viewmodel.JarvisViewModel
import com.example.ui.viewmodel.StreamState

@Composable
fun SystemScreen(
    viewModel: JarvisViewModel,
    onSignedOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val voicePresets by viewModel.allVoicePresets.collectAsStateWithLifecycle()
    val battery by viewModel.batteryStatus.collectAsStateWithLifecycle()
    val simSlots by viewModel.simSlots.collectAsStateWithLifecycle()
    val simPlansState by viewModel.simPlansState.collectAsStateWithLifecycle()

    var showAddVoiceDialog by remember { mutableStateOf(false) }
    var editingSimSlot by remember { mutableStateOf<Int?>(null) }

    val phonePermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.refreshHardwareTelemetry(context)
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    var resumeTick by remember { mutableIntStateOf(0) }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                resumeTick++
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val activeVoiceId = userProfile?.preferredVoiceId ?: "jarvis_classic"
    val batteryAlertsEnabled = userProfile?.batteryAlertsEnabled ?: true
    val userVoiceConsent = userProfile?.customUserVoiceConsent ?: false
    val isDeviceAdmin = remember(resumeTick) { PhoneCommsHelper.isDeviceAdminActive(context) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Voice Styles
        item {
            HudSectionHeader(
                title = "Voice Styles (${voicePresets.size})",
                subtitle = "Original Stark-inspired, deep, calm, energetic & consented personal voice",
                icon = Icons.Default.RecordVoiceOver
            )
            HudCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("User Voice Consent", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Enable your own custom voice profile option only with your explicit consent.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = userVoiceConsent,
                        onCheckedChange = { viewModel.updatePreferences(customVoiceConsent = it) }
                    )
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { showAddVoiceDialog = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Add Custom Voice Style")
                }
            }
        }

        items(voicePresets, key = { it.id }) { preset ->
            val selected = preset.id == activeVoiceId
            val lockedOwnVoice = preset.isUserOwnVoice && !userVoiceConsent
            HudCard(
                borderColor = if (selected) ArcCyan else HudBorder
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(preset.name, style = MaterialTheme.typography.titleMedium, color = if (selected) ArcCyan else MaterialTheme.colorScheme.onSurface)
                        Text(preset.subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Pitch ${preset.pitch}x • Speed ${preset.speechRate}x", style = MaterialTheme.typography.labelSmall, color = StarkAmber)
                    }
                    Button(
                        onClick = { viewModel.selectVoicePreset(preset) },
                        enabled = !lockedOwnVoice,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selected) NominalGreen else ArcCyan,
                            contentColor = VoidBlack
                        )
                    ) {
                        Text(if (selected) "Active" else if (lockedOwnVoice) "Consent Off" else "Activate")
                    }
                }
            }
        }

        // 2. Battery & Charging Alerts
        item {
            HudSectionHeader(
                title = "Battery & Charging Alerts",
                subtitle = "Deduplicated voice announcements at 20%, 10%, Plug-in, 50% & 100%",
                icon = Icons.Default.BatteryChargingFull
            )
            HudCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (battery.percentage >= 0) "${battery.percentage}% (${battery.pluggedSource})" else "Reading...",
                            style = MaterialTheme.typography.headlineSmall,
                            color = if (battery.percentage <= 20) StarkAmber else NominalGreen
                        )
                        Text("Session Drop: ${battery.dropSinceSessionStart}%", style = MaterialTheme.typography.bodyMedium)
                        if (battery.lastAnnouncement.isNotBlank()) {
                            Text("Last Alert: ${battery.lastAnnouncement}", style = MaterialTheme.typography.labelSmall, color = ArcCyan)
                        }
                    }
                    Switch(
                        checked = batteryAlertsEnabled,
                        onCheckedChange = { viewModel.updatePreferences(batteryAlertsEnabled = it) }
                    )
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        val msg = if (battery.percentage >= 0) {
                            "अभी battery ${battery.percentage}% है और status ${battery.pluggedSource} है।"
                        } else {
                            "Battery telemetry ready."
                        }
                        viewModel.speakOut(msg, "hi")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Announce Current Battery Status")
                }
            }
        }

        // 3. Dual-SIM & Recharge Checker
        item {
            HudSectionHeader(
                title = "Dual-SIM & Recharge Checker",
                subtitle = "SIM 1 & SIM 2 carrier detection + plan expiry tracker & official carrier apps",
                icon = Icons.Default.SimCard
            )
            HudCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Hardware SIM Slots (${simSlots.size} detected)", style = MaterialTheme.typography.titleMedium, color = ArcCyan)
                    OutlinedButton(onClick = {
                        if (PhoneCommsHelper.hasPermission(context, Manifest.permission.READ_PHONE_STATE)) {
                            viewModel.refreshHardwareTelemetry(context)
                        } else {
                            phonePermLauncher.launch(Manifest.permission.READ_PHONE_STATE)
                        }
                    }) {
                        Text("Detect SIMs")
                    }
                }
                Spacer(Modifier.height(6.dp))
                if (simSlots.isEmpty()) {
                    Text(
                        "Grant Phone State permission to read SIM 1 & SIM 2 operator names (Jio, Airtel, Vi, BSNL).",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    simSlots.forEach { slot ->
                        Text(
                            "SIM ${slot.slotIndex}: ${slot.carrierName} (${slot.countryIso}) ${if (slot.isRoaming) "[ROAMING]" else ""}",
                            style = MaterialTheme.typography.bodyLarge,
                            color = NominalGreen
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Note: Telecom operators do not provide private balance/remaining-GB APIs to third-party apps. Track your active plan below or open your official carrier app:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Jio", "Airtel", "Vi", "BSNL").forEach { op ->
                        OutlinedButton(
                            onClick = { PhoneCommsHelper.openCarrierAppOrPortal(context, op) },
                            modifier = Modifier.weight(1f)
                        ) { Text(op, style = MaterialTheme.typography.labelSmall) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { editingSimSlot = 1 },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = VoidBlack)
                    ) { Text("Update SIM 1 Plan") }
                    Button(
                        onClick = { editingSimSlot = 2 },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = VoidBlack)
                    ) { Text("Update SIM 2 Plan") }
                }

                val plans = (simPlansState as? StreamState.Success)?.data.orEmpty()
                plans.forEach { p ->
                    Spacer(Modifier.height(8.dp))
                    val lowAlert = p.validityDays <= 3 || p.remainingDataGb <= 0.5
                    StatusPill(
                        label = "SIM ${p.simSlot} (${p.operatorName}): ${p.planName} • ₹${p.planPriceInr.toInt()} • ${p.remainingDataGb}GB left • Exp ${p.expiryDateKey}",
                        color = if (lowAlert) StarkAmber else NominalGreen
                    )
                }
            }
        }

        // 4. Voice Lock & Biometric Unlock
        item {
            HudSectionHeader(
                title = "Voice Lock & Secure Unlock",
                subtitle = "Device Admin screen lock + Biometric/PIN verified unlock (never bypasses OS security)",
                icon = Icons.Default.Lock
            )
            HudCard {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            if (isDeviceAdmin) {
                                PhoneCommsHelper.lockScreenIfPermitted(context)
                            } else {
                                PhoneCommsHelper.requestDeviceAdminActivation(context)
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("lock_screen_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = StarkAmber, contentColor = VoidBlack)
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (isDeviceAdmin) "Lock Screen" else "Enable Lock Admin")
                    }
                    Button(
                        onClick = {
                            val act = context as? FragmentActivity
                            if (act != null) {
                                PhoneCommsHelper.promptSecureBiometricUnlock(
                                    activity = act,
                                    onAuthenticated = { viewModel.speakOut("Biometric verification complete. Systems unlocked.") },
                                    onError = {}
                                )
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("secure_unlock_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = NominalGreen, contentColor = VoidBlack)
                    ) {
                        Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Secure Unlock")
                    }
                }
            }
        }

        // 5. Security, Permissions Transparency & Account Sign-Out
        item {
            HudSectionHeader(
                title = "Security & Permissions Status",
                subtitle = "Explicit consent, zero credential storage & Android OS capability status",
                icon = Icons.Default.Security
            )
            HudCard {
                val perms = remember(resumeTick) {
                    listOf(
                        "Microphone (Voice Input)" to PhoneCommsHelper.hasPermission(context, Manifest.permission.RECORD_AUDIO),
                        "Camera (AI Vision)" to PhoneCommsHelper.hasPermission(context, Manifest.permission.CAMERA),
                        "Location (Live Share)" to PhoneCommsHelper.hasPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION),
                        "Contacts (Calling)" to PhoneCommsHelper.hasPermission(context, Manifest.permission.READ_CONTACTS),
                        "Phone/SIM State" to PhoneCommsHelper.hasPermission(context, Manifest.permission.READ_PHONE_STATE),
                        "Device Admin (Lock)" to isDeviceAdmin
                    )
                }
                perms.forEach { (label, ok) ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(label, style = MaterialTheme.typography.bodyMedium)
                        StatusPill(
                            label = if (ok) "GRANTED" else "NOT GRANTED",
                            color = if (ok) NominalGreen else StarkAmber
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = {
                        signOutJarvis(credentialManager, scope, onSignedOut)
                    },
                    modifier = Modifier.fillMaxWidth().testTag("sign_out_button"),
                    border = BorderStroke(1.dp, AlertRed.copy(alpha = 0.7f))
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = AlertRed)
                    Spacer(Modifier.width(8.dp))
                    Text("Sign Out of Google Account", color = AlertRed)
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }

    if (showAddVoiceDialog) {
        var name by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var pitch by remember { mutableFloatStateOf(1.0f) }
        var rate by remember { mutableFloatStateOf(1.0f) }

        AlertDialog(
            onDismissRequest = { showAddVoiceDialog = false },
            title = { Text("Add Custom Voice Style") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Voice Name") })
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Tone Description") })
                    Text("Pitch: ${"%.2f".format(pitch)}x")
                    Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.5f..1.6f)
                    Text("Speed: ${"%.2f".format(rate)}x")
                    Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.6f..1.5f)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addCustomVoiceProfile(name, desc, pitch.toDouble(), rate.toDouble(), false, true)
                        showAddVoiceDialog = false
                    },
                    enabled = name.isNotBlank()
                ) { Text("Save Voice") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddVoiceDialog = false }) { Text("Cancel") }
            }
        )
    }

    editingSimSlot?.let { slot ->
        val defaultExpiry = remember {
            SimpleDateFormat("yyyy-MM-dd", Locale.US)
                .format(Date(System.currentTimeMillis() + 28L * 24L * 60L * 60L * 1000L))
        }
        var operator by remember { mutableStateOf("Jio") }
        var planName by remember { mutableStateOf("True 5G 299") }
        var price by remember { mutableStateOf("299") }
        var dataGb by remember { mutableStateOf("1.5") }
        var days by remember { mutableStateOf("28") }
        var expiry by remember { mutableStateOf(defaultExpiry) }

        AlertDialog(
            onDismissRequest = { editingSimSlot = null },
            title = { Text("Update SIM $slot Recharge Plan") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = operator, onValueChange = { operator = it }, label = { Text("Operator (Jio/Airtel/Vi/BSNL)") })
                    OutlinedTextField(value = planName, onValueChange = { planName = it }, label = { Text("Plan Name") })
                    OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Price (₹)") })
                    OutlinedTextField(value = dataGb, onValueChange = { dataGb = it }, label = { Text("Remaining Data (GB)") })
                    OutlinedTextField(value = days, onValueChange = { days = it }, label = { Text("Validity Days Left") })
                    OutlinedTextField(value = expiry, onValueChange = { expiry = it }, label = { Text("Expiry Date") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.saveSimPlan(
                        SimPlan(
                            simSlot = slot,
                            operatorName = operator,
                            planName = planName,
                            planPriceInr = price.toDoubleOrNull() ?: 0.0,
                            remainingDataGb = dataGb.toDoubleOrNull() ?: 0.0,
                            validityDays = days.toIntOrNull() ?: 0,
                            expiryDateKey = expiry
                        )
                    )
                    editingSimSlot = null
                }) { Text("Save Plan") }
            },
            dismissButton = {
                OutlinedButton(onClick = { editingSimSlot = null }) { Text("Cancel") }
            }
        )
    }
}
