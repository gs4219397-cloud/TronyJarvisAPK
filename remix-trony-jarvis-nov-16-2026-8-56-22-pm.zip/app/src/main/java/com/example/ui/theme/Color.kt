package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val VoidBlack = Color(0xFF040812)
val DeepSpace = Color(0xFF07101F)
val HudSurface = Color(0xFF0C182E)
val HudSurfaceElevated = Color(0xFF122340)
val HudBorder = Color(0xFF1E3A5F)

val ArcCyan = Color(0xFF00E5FF)
val ArcCyanDim = Color(0xFF0099B8)
val HoloBlue = Color(0xFF38BDF8)
val StarkCobalt = Color(0xFF1D4ED8)
val StarkAmber = Color(0xFFFFB020)
val NominalGreen = Color(0xFF10B981)
val AlertRed = Color(0xFFEF4444)

val TextPrimary = Color(0xFFE6F4FF)
val TextSecondary = Color(0xFF94B2CE)
val TextMuted = Color(0xFF5D7B99)
