package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val JarvisColorScheme = darkColorScheme(
    primary = ArcCyan,
    onPrimary = VoidBlack,
    primaryContainer = HudSurfaceElevated,
    onPrimaryContainer = ArcCyan,
    secondary = HoloBlue,
    onSecondary = VoidBlack,
    secondaryContainer = StarkCobalt,
    onSecondaryContainer = TextPrimary,
    tertiary = StarkAmber,
    onTertiary = VoidBlack,
    background = VoidBlack,
    onBackground = TextPrimary,
    surface = HudSurface,
    onSurface = TextPrimary,
    surfaceVariant = HudSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = HudBorder,
    error = AlertRed,
    onError = TextPrimary
)

private val JarvisShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp)
)

@Composable
fun TronyJarvisTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        typography = Typography,
        shapes = JarvisShapes,
        content = content
    )
}
