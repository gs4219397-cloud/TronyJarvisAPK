package com.example.ui.screens

import android.Manifest
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.core.graphics.scale
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.example.data.model.ShoppingProduct
import com.example.data.model.SocialReport
import com.example.system.PhoneCommsHelper
import com.example.ui.components.HudCard
import com.example.ui.components.HudSectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.HudSurface
import com.example.ui.theme.NominalGreen
import com.example.ui.theme.StarkAmber
import com.example.ui.theme.VoidBlack
import com.example.ui.viewmodel.FeatureState
import com.example.ui.viewmodel.JarvisViewModel
import com.example.ui.viewmodel.StreamState

@Composable
fun HubScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    var selectedSubTab by remember { mutableIntStateOf(0) }
    val subTabs = listOf("Vision", "Shopping", "Tickets & OTT", "Social Report")

    Column(modifier = modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = HudSurface,
            contentColor = ArcCyan
        ) {
            subTabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedSubTab == index,
                    onClick = { selectedSubTab = index },
                    text = { Text(title, style = MaterialTheme.typography.labelMedium) }
                )
            }
        }

        when (selectedSubTab) {
            0 -> VisionSubTab(viewModel)
            1 -> ShoppingSubTab(viewModel)
            2 -> TicketsAndMoviesSubTab(viewModel)
            3 -> SocialReportSubTab(viewModel)
        }
    }
}

@Composable
private fun VisionSubTab(viewModel: JarvisViewModel) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val visionState by viewModel.visionState.collectAsStateWithLifecycle()

    var hasCameraPerm by remember {
        mutableStateOf(PhoneCommsHelper.hasPermission(context, Manifest.permission.CAMERA))
    }
    var cameraActive by remember { mutableStateOf(false) }
    var cameraError by remember { mutableStateOf<String?>(null) }
    val imageCapture = remember { ImageCapture.Builder().build() }

    DisposableEffect(cameraActive) {
        onDispose {
            try {
                ProcessCameraProvider.getInstance(context).get().unbindAll()
            } catch (_: Exception) {
            }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPerm = granted
        if (granted) {
            cameraError = null
            cameraActive = true
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val bmp = decodeScaledBitmap(context, uri)
            if (bmp != null) {
                viewModel.analyzeVisionImage(bmp)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            HudSectionHeader(
                title = "AI Camera & Vision",
                subtitle = "Appearance, beard/hairstyle, outfit colors, expression cues & YouTube mood music",
                icon = Icons.Default.CameraAlt
            )
        }

        item {
            HudCard {
                if (cameraActive && hasCameraPerm) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(RoundedCornerShape(12.dp))
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                val previewView = PreviewView(ctx)
                                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                                cameraProviderFuture.addListener({
                                    try {
                                        val provider = cameraProviderFuture.get()
                                        val preview = Preview.Builder().build().also {
                                            it.surfaceProvider = previewView.surfaceProvider
                                        }
                                        val selector = when {
                                            provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) ->
                                                CameraSelector.DEFAULT_FRONT_CAMERA
                                            provider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA) ->
                                                CameraSelector.DEFAULT_BACK_CAMERA
                                            else -> null
                                        }
                                        if (selector == null) {
                                            cameraError = "No camera hardware available on this device. Use 'Analyze Photo' instead."
                                            cameraActive = false
                                        } else {
                                            provider.unbindAll()
                                            provider.bindToLifecycle(lifecycleOwner, selector, preview, imageCapture)
                                        }
                                    } catch (e: Exception) {
                                        Log.e("VisionCamera", "Camera bind failed", e)
                                        cameraError = "Camera initialization error: ${e.localizedMessage ?: "Unavailable"}"
                                        cameraActive = false
                                    }
                                }, ContextCompat.getMainExecutor(ctx))
                                previewView
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                }
                if (cameraError != null) {
                    Text(
                        text = cameraError ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = StarkAmber
                    )
                    Spacer(Modifier.height(8.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            if (!hasCameraPerm) {
                                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            } else if (!cameraActive) {
                                cameraActive = true
                            } else {
                                imageCapture.takePicture(
                                    ContextCompat.getMainExecutor(context),
                                    object : ImageCapture.OnImageCapturedCallback() {
                                        override fun onCaptureSuccess(image: ImageProxy) {
                                            val bmp = imageProxyToScaledBitmap(image)
                                            image.close()
                                            if (bmp != null) {
                                                viewModel.analyzeVisionImage(bmp)
                                            }
                                        }

                                        override fun onError(exception: ImageCaptureException) {
                                            Log.e("VisionCamera", "Capture failed", exception)
                                        }
                                    }
                                )
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("vision_camera_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = VoidBlack)
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (cameraActive && hasCameraPerm) "Analyze Frame" else "Open Camera")
                    }

                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.weight(1f).testTag("vision_picker_button")
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Analyze Photo")
                    }
                }
            }
        }

        when (val st = visionState) {
            FeatureState.Idle -> Unit
            FeatureState.Loading -> {
                item {
                    HudCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(color = ArcCyan, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(12.dp))
                            Text("Gemini Vision analyzing appearance & outfit...")
                        }
                    }
                }
            }
            is FeatureState.Error -> {
                item { Text(st.message, color = AlertRed) }
            }
            is FeatureState.Success -> {
                val res = st.data
                item {
                    HudCard(borderColor = NominalGreen.copy(alpha = 0.7f)) {
                        Text("Vision Observation", style = MaterialTheme.typography.titleMedium, color = ArcCyan)
                        Spacer(Modifier.height(6.dp))
                        Text(res.appearanceSummary, style = MaterialTheme.typography.bodyLarge)
                        Spacer(Modifier.height(8.dp))
                        Text("Beard & Moustache: ${res.beardAndMoustache}", style = MaterialTheme.typography.bodyMedium)
                        Text("Hairstyle: ${res.hairstyle}", style = MaterialTheme.typography.bodyMedium)
                        Text("Outfit & Colors: ${res.outfitAndColors}", style = MaterialTheme.typography.bodyMedium)
                        Text("Expression Cue: ${res.observedExpression}", style = MaterialTheme.typography.bodyMedium, color = StarkAmber)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = res.expressionDisclaimer,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(10.dp))
                        HudCard(containerColor = HudSurface) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = NominalGreen)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "Suggested ${res.moodCategory.uppercase()} Music",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = NominalGreen
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(res.musicReason, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = { PhoneCommsHelper.openYouTubeSearch(context, res.musicSuggestionQuery) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = NominalGreen, contentColor = VoidBlack)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("Open '${res.musicSuggestionQuery}' on YouTube")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShoppingSubTab(viewModel: JarvisViewModel) {
    val shoppingState by viewModel.shoppingState.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("Phone under ₹20,000") }
    var checkoutProduct by remember { mutableStateOf<ShoppingProduct?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            HudSectionHeader(
                title = "Shopping Assistant",
                subtitle = "Amazon, Flipkart & Meesho specs comparison, taxes & secure checkout prep",
                icon = Icons.Default.ShoppingBag
            )
            HudCard {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Product or budget query (e.g. ₹20,000 के अंदर phone)") },
                    modifier = Modifier.fillMaxWidth().testTag("shopping_query_input"),
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { viewModel.runShoppingSearch(query) },
                    enabled = query.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().testTag("shopping_search_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = VoidBlack)
                ) {
                    Icon(Icons.Default.Search, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Compare Products")
                }
            }
        }

        when (val st = shoppingState) {
            FeatureState.Idle -> Unit
            FeatureState.Loading -> {
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        CircularProgressIndicator(color = ArcCyan)
                    }
                }
            }
            is FeatureState.Error -> item { Text(st.message, color = AlertRed) }
            is FeatureState.Success -> {
                items(st.data) { prod ->
                    HudCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(prod.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            StatusPill(label = prod.platform.uppercase(), color = StarkAmber)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("${prod.priceInr} • ${prod.rating} • Seller: ${prod.seller}", style = MaterialTheme.typography.labelMedium, color = NominalGreen)
                        Spacer(Modifier.height(6.dp))
                        Text("RAM/Storage: ${prod.ramStorage}", style = MaterialTheme.typography.bodyMedium)
                        Text("Processor: ${prod.processor}", style = MaterialTheme.typography.bodyMedium)
                        Text("Camera: ${prod.camera} • Battery: ${prod.battery}", style = MaterialTheme.typography.bodyMedium)
                        Text("Display: ${prod.display}", style = MaterialTheme.typography.bodyMedium)
                        Text(prod.deliveryAndTaxes, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { checkoutProduct = prod },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = VoidBlack)
                        ) {
                            Text("Prepare Secure Checkout (UPI / Card)")
                        }
                    }
                }
            }
        }
    }

    checkoutProduct?.let { prod ->
        var address by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var paymentMethod by remember { mutableStateOf("UPI") }

        AlertDialog(
            onDismissRequest = { checkoutProduct = null },
            title = { Text("Checkout Preparation") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${prod.name} (${prod.priceInr})", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Delivery Address") })
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Contact Phone") })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("UPI", "Debit Card").forEach { method ->
                            FilterChip(
                                selected = paymentMethod == method,
                                onClick = { paymentMethod = method },
                                label = { Text(method) }
                            )
                        }
                    }
                    Text(
                        "Security: You will enter PIN, CVV, or OTP directly on ${prod.platform}'s official payment page.",
                        style = MaterialTheme.typography.labelSmall,
                        color = StarkAmber
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.prepareShoppingCheckout(prod, address, phone, paymentMethod)
                    checkoutProduct = null
                }) { Text("Review Final Order") }
            },
            dismissButton = {
                OutlinedButton(onClick = { checkoutProduct = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun TicketsAndMoviesSubTab(viewModel: JarvisViewModel) {
    val context = LocalContext.current
    val ticketState by viewModel.ticketState.collectAsStateWithLifecycle()
    val movieState by viewModel.movieState.collectAsStateWithLifecycle()

    val defaultTravelDate = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.US)
            .format(Date(System.currentTimeMillis() + 7L * 24L * 60L * 60L * 1000L))
    }
    var bookingType by remember { mutableStateOf("Train") }
    var ticketQuery by remember { mutableStateOf("Delhi to Mumbai") }
    var ticketDate by remember { mutableStateOf(defaultTravelDate) }
    var passengerCount by remember { mutableIntStateOf(1) }

    var movieQuery by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            HudSectionHeader(
                title = "Online Ticket Booking",
                subtitle = "Train, Movie & Travel planning with official platform confirmation",
                icon = Icons.Default.ConfirmationNumber
            )
            HudCard {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Train", "Movie", "Bus / Flight").forEach { t ->
                        FilterChip(selected = bookingType == t, onClick = { bookingType = t }, label = { Text(t) })
                    }
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = ticketQuery,
                    onValueChange = { ticketQuery = it },
                    label = { Text("Route or Movie / Show") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = ticketDate,
                        onValueChange = { ticketDate = it },
                        label = { Text("Date") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = passengerCount.toString(),
                        onValueChange = { passengerCount = it.toIntOrNull()?.coerceIn(1, 10) ?: 1 },
                        label = { Text("Seats") },
                        modifier = Modifier.weight(0.6f),
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { viewModel.runTicketPlanning(bookingType, ticketQuery, ticketDate) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = VoidBlack)
                ) {
                    Text("Find Official Ticket Options")
                }
            }
        }

        when (val st = ticketState) {
            FeatureState.Idle -> Unit
            FeatureState.Loading -> item { CircularProgressIndicator(color = ArcCyan) }
            is FeatureState.Error -> item { Text(st.message, color = AlertRed) }
            is FeatureState.Success -> {
                items(st.data) { opt ->
                    HudCard {
                        Text("${opt.bookingType}: ${opt.title}", style = MaterialTheme.typography.titleMedium, color = ArcCyan)
                        Text("${opt.dateText} • ${opt.timeText} • ${opt.seatInfo}", style = MaterialTheme.typography.bodyMedium)
                        Text("Est. Price: ${opt.estimatedPriceInr} • ${opt.officialPlatformName}", style = MaterialTheme.typography.labelMedium, color = NominalGreen)
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { viewModel.prepareTicketBooking(opt, passengerCount) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Review & Book on ${opt.officialPlatformName}")
                        }
                    }
                }
            }
        }

        item {
            HudSectionHeader(
                title = "Official Movie Search",
                subtitle = "Google, YouTube, Netflix & OTT watch/rent/offline options (Zero piracy)",
                icon = Icons.Default.Movie
            )
            HudCard {
                OutlinedTextField(
                    value = movieQuery,
                    onValueChange = { movieQuery = it },
                    label = { Text("Movie name") },
                    modifier = Modifier.fillMaxWidth().testTag("movie_search_input"),
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.runMovieSearch(movieQuery) },
                        enabled = movieQuery.isNotBlank(),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = VoidBlack)
                    ) { Text("Find Official OTT") }
                    OutlinedButton(
                        onClick = { PhoneCommsHelper.openYouTubeSearch(context, "$movieQuery official trailer movie") },
                        enabled = movieQuery.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    ) { Text("YouTube") }
                }
            }
        }

        when (val st = movieState) {
            FeatureState.Idle -> Unit
            FeatureState.Loading -> item { CircularProgressIndicator(color = ArcCyan) }
            is FeatureState.Error -> item { Text(st.message, color = AlertRed) }
            is FeatureState.Success -> {
                val m = st.data
                item {
                    HudCard(borderColor = NominalGreen.copy(alpha = 0.6f)) {
                        Text("${m.title} (${m.year})", style = MaterialTheme.typography.titleMedium, color = ArcCyan)
                        Text("Language: ${m.language}", style = MaterialTheme.typography.labelMedium, color = StarkAmber)
                        Spacer(Modifier.height(6.dp))
                        Text(m.summary, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(6.dp))
                        Text("Official Platforms: ${m.ottPlatforms.joinToString(", ")}", style = MaterialTheme.typography.labelMedium, color = NominalGreen)
                        Text(m.officialNote, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { PhoneCommsHelper.openUrl(context, "https://www.google.com/search?q=${Uri.encode("${m.title} watch online official")}") },
                                modifier = Modifier.weight(1f)
                            ) { Text("Google Watch") }
                            OutlinedButton(
                                onClick = { PhoneCommsHelper.openYouTubeSearch(context, "${m.title} official movie") },
                                modifier = Modifier.weight(1f)
                            ) { Text("YouTube Movies") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SocialReportSubTab(viewModel: JarvisViewModel) {
    val reportsState by viewModel.socialReportsState.collectAsStateWithLifecycle()
    var periodFilter by remember { mutableStateOf("all") }
    var showAddDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            HudSectionHeader(
                title = "Social Media Complete Report",
                subtitle = "Official-access snapshots for Facebook, Instagram, X & Messenger (₹ INR)",
                icon = Icons.Default.Analytics
            )
            HudCard(borderColor = StarkAmber.copy(alpha = 0.6f)) {
                Text("Official Platform Data Policy", style = MaterialTheme.typography.titleMedium, color = StarkAmber)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Facebook, Instagram, X, and Messenger do not expose private earnings or unfollower lists without official OAuth/Graph API tokens. Log your verified dashboard snapshots here for permanent daily, monthly & yearly ₹ INR totals and voice queries.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { showAddDialog = true },
                        modifier = Modifier.weight(1f).testTag("add_social_snapshot_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = VoidBlack)
                    ) { Text("Log Snapshot") }
                    OutlinedButton(
                        onClick = { viewModel.speakOut(viewModel.buildSocialSummaryText(), "hi") },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Voice Report")
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("all", "daily", "monthly", "yearly").forEach { p ->
                    FilterChip(
                        selected = periodFilter == p,
                        onClick = { periodFilter = p },
                        label = { Text(p.uppercase(), style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        when (val st = reportsState) {
            StreamState.Loading -> item { CircularProgressIndicator(color = ArcCyan) }
            is StreamState.Error -> item { Text(st.message, color = AlertRed) }
            is StreamState.Success -> {
                val filtered = st.data.filter { periodFilter == "all" || it.periodType == periodFilter }
                val totalEarnings = filtered.sumOf { it.earningsInr }
                item {
                    HudCard(borderColor = NominalGreen.copy(alpha = 0.7f)) {
                        Text("Total Verified Earnings (${periodFilter.uppercase()})", style = MaterialTheme.typography.labelMedium, color = NominalGreen)
                        Text("₹ ${"%.2f".format(totalEarnings)}", style = MaterialTheme.typography.displaySmall, color = NominalGreen)
                    }
                }
                if (filtered.isEmpty()) {
                    item {
                        HudCard {
                            Text("No social snapshots logged yet. Tap 'Log Snapshot' to record verified Facebook, Instagram, X, or Messenger stats.")
                        }
                    }
                } else {
                    items(filtered, key = { it.id }) { rep ->
                        HudCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${rep.platform.uppercase()} • ${rep.periodType.uppercase()}", style = MaterialTheme.typography.titleMedium, color = ArcCyan)
                                StatusPill(label = rep.dateKey, color = StarkAmber)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("Followers: ${rep.totalFollowers} (+${rep.newFollowers} new) • Views/Impressions: ${rep.viewsOrImpressions}", style = MaterialTheme.typography.bodyMedium)
                            Text("Likes: ${rep.likes} • Comments: ${rep.comments} • Shares: ${rep.shares} • Msgs: ${rep.messagesCount}", style = MaterialTheme.typography.bodyMedium)
                            if (rep.earningsInr > 0.0) {
                                Text("Earnings: ₹${"%.2f".format(rep.earningsInr)}", style = MaterialTheme.typography.labelMedium, color = NominalGreen)
                            }
                            Text("Source: ${rep.dataSource} | ${rep.unfollowersNote}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
        var platform by remember { mutableStateOf("facebook") }
        var period by remember { mutableStateOf("daily") }
        var dateKey by remember { mutableStateOf(todayStr) }
        var followers by remember { mutableStateOf("") }
        var newFollowers by remember { mutableStateOf("") }
        var views by remember { mutableStateOf("") }
        var likes by remember { mutableStateOf("") }
        var earnings by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Log Official Social Snapshot") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("facebook", "instagram", "x", "messenger").forEach { p ->
                            FilterChip(selected = platform == p, onClick = { platform = p }, label = { Text(p) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("daily", "monthly", "yearly").forEach { pt ->
                            FilterChip(selected = period == pt, onClick = { period = pt }, label = { Text(pt) })
                        }
                    }
                    OutlinedTextField(value = dateKey, onValueChange = { dateKey = it }, label = { Text("Date / Period Key") }, singleLine = true)
                    OutlinedTextField(value = followers, onValueChange = { followers = it }, label = { Text("Total Followers") }, singleLine = true)
                    OutlinedTextField(value = newFollowers, onValueChange = { newFollowers = it }, label = { Text("New Followers") }, singleLine = true)
                    OutlinedTextField(value = views, onValueChange = { views = it }, label = { Text("Views / Impressions") }, singleLine = true)
                    OutlinedTextField(value = likes, onValueChange = { likes = it }, label = { Text("Likes / Messages") }, singleLine = true)
                    OutlinedTextField(value = earnings, onValueChange = { earnings = it }, label = { Text("Earnings (₹ INR)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.saveSocialReport(
                        SocialReport(
                            platform = platform,
                            periodType = period,
                            dateKey = dateKey,
                            totalFollowers = followers.toLongOrNull() ?: 0L,
                            newFollowers = newFollowers.toLongOrNull() ?: 0L,
                            viewsOrImpressions = views.toLongOrNull() ?: 0L,
                            likes = likes.toLongOrNull() ?: 0L,
                            earningsInr = earnings.toDoubleOrNull() ?: 0.0,
                            dataSource = "Official Account Dashboard"
                        )
                    )
                    showAddDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddDialog = false }) { Text("Cancel") }
            }
        )
    }
}

private fun decodeScaledBitmap(context: android.content.Context, uri: Uri): Bitmap? {
    return try {
        val raw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
        scaleDownBitmap(raw, 1024)
    } catch (e: Exception) {
        Log.e("VisionBitmap", "Failed to decode URI bitmap", e)
        null
    }
}

private fun imageProxyToScaledBitmap(image: ImageProxy): Bitmap? {
    return try {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        val rotation = image.imageInfo.rotationDegrees
        val oriented = if (rotation != 0) {
            val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
            Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        } else {
            decoded
        }
        scaleDownBitmap(oriented, 1024)
    } catch (e: Exception) {
        Log.e("VisionBitmap", "Failed to decode ImageProxy", e)
        null
    }
}

private fun scaleDownBitmap(src: Bitmap, maxDim: Int): Bitmap {
    val ratio = minOf(maxDim.toFloat() / src.width, maxDim.toFloat() / src.height, 1f)
    if (ratio >= 1f) return src
    return src.scale(
        (src.width * ratio).toInt().coerceAtLeast(1),
        (src.height * ratio).toInt().coerceAtLeast(1)
    )
}
