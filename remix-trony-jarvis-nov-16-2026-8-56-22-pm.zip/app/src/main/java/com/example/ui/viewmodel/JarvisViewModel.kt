package com.example.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.core.net.toUri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AllowlistContact
import com.example.data.model.BatteryStatus
import com.example.data.model.ChatMessage
import com.example.data.model.DeleteRecord
import com.example.data.model.DeviceContact
import com.example.data.model.JarvisCoreState
import com.example.data.model.MovieSearchResult
import com.example.data.model.PendingConfirmation
import com.example.data.model.ShoppingProduct
import com.example.data.model.SimPlan
import com.example.data.model.SimSlotInfo
import com.example.data.model.SocialReport
import com.example.data.model.TicketBookingOption
import com.example.data.model.UserProfile
import com.example.data.model.VisionAnalysisResult
import com.example.data.model.VoiceProfile
import com.example.data.model.VoiceStylePreset
import com.example.data.repository.AiIntentAction
import com.example.data.repository.JarvisAiRepository
import com.example.data.repository.JarvisFirestoreRepository
import com.example.system.BatteryMonitor
import com.example.system.JarvisCallScreeningService
import com.example.system.JarvisVoiceEngine
import com.example.system.PhoneCommsHelper
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

sealed interface StreamState<out T> {
    data object Loading : StreamState<Nothing>
    data class Success<T>(val data: T) : StreamState<T>
    data class Error(val message: String) : StreamState<Nothing>
}

sealed interface FeatureState<out T> {
    data object Idle : FeatureState<Nothing>
    data object Loading : FeatureState<Nothing>
    data class Success<T>(val data: T) : FeatureState<T>
    data class Error(val message: String) : FeatureState<Nothing>
}

class JarvisViewModel(
    private val firestoreRepo: JarvisFirestoreRepository,
    private val aiRepo: JarvisAiRepository,
    val currentUserId: String,
    private val userDisplayName: String
) : ViewModel() {

    private var voiceEngine: JarvisVoiceEngine? = null
    private var batteryMonitor: BatteryMonitor? = null

    private val _isListening = MutableStateFlow(false)
    private val _isThinking = MutableStateFlow(false)
    private val _isSpeaking = MutableStateFlow(false)

    val coreState: StateFlow<JarvisCoreState> = combine(
        _isListening, _isThinking, _isSpeaking
    ) { listening, thinking, speaking ->
        when {
            listening -> JarvisCoreState.LISTENING
            thinking -> JarvisCoreState.THINKING
            speaking -> JarvisCoreState.SPEAKING
            else -> JarvisCoreState.IDLE
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), JarvisCoreState.IDLE)

    private val _partialSpeech = MutableStateFlow("")
    val partialSpeech: StateFlow<String> = _partialSpeech.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _chatMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                id = "welcome",
                isUser = false,
                text = "Systems online. Namaste! I am TRONY AI JARVIS. Say 'Hi JARVIS' or tap the Arc Reactor mic to speak in Hindi, Bengali, Tamil, or English."
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _pendingConfirmation = MutableStateFlow<PendingConfirmation?>(null)
    val pendingConfirmation: StateFlow<PendingConfirmation?> = _pendingConfirmation.asStateFlow()

    private val _batteryStatus = MutableStateFlow(BatteryStatus())
    val batteryStatus: StateFlow<BatteryStatus> = _batteryStatus.asStateFlow()

    private val _simSlots = MutableStateFlow<List<SimSlotInfo>>(emptyList())
    val simSlots: StateFlow<List<SimSlotInfo>> = _simSlots.asStateFlow()

    private val _deviceContacts = MutableStateFlow<List<DeviceContact>>(emptyList())
    val deviceContacts: StateFlow<List<DeviceContact>> = _deviceContacts.asStateFlow()

    private val _visionState = MutableStateFlow<FeatureState<VisionAnalysisResult>>(FeatureState.Idle)
    val visionState: StateFlow<FeatureState<VisionAnalysisResult>> = _visionState.asStateFlow()

    private val _shoppingState = MutableStateFlow<FeatureState<List<ShoppingProduct>>>(FeatureState.Idle)
    val shoppingState: StateFlow<FeatureState<List<ShoppingProduct>>> = _shoppingState.asStateFlow()

    private val _movieState = MutableStateFlow<FeatureState<MovieSearchResult>>(FeatureState.Idle)
    val movieState: StateFlow<FeatureState<MovieSearchResult>> = _movieState.asStateFlow()

    private val _ticketState = MutableStateFlow<FeatureState<List<TicketBookingOption>>>(FeatureState.Idle)
    val ticketState: StateFlow<FeatureState<List<TicketBookingOption>>> = _ticketState.asStateFlow()

    private val _pendingMediaDeleteUri = MutableStateFlow<Pair<Uri, String>?>(null)
    val pendingMediaDeleteUri: StateFlow<Pair<Uri, String>?> = _pendingMediaDeleteUri.asStateFlow()

    private val _unlockPromptTrigger = MutableStateFlow(false)
    val unlockPromptTrigger: StateFlow<Boolean> = _unlockPromptTrigger.asStateFlow()

    val userProfile: StateFlow<UserProfile?> = firestoreRepo.observeUserProfile(currentUserId)
        .catch { err ->
            handleFlowError("userProfile", err)
            emit(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val deleteRecordsState: StateFlow<StreamState<List<DeleteRecord>>> =
        firestoreRepo.observeDeleteRecords(currentUserId)
            .map<List<DeleteRecord>, StreamState<List<DeleteRecord>>> { StreamState.Success(it) }
            .catch { err -> emit(StreamState.Error(unwrapFirestoreMsg(err, "Failed to load delete records"))) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), StreamState.Loading)

    val allowlistState: StateFlow<StreamState<List<AllowlistContact>>> =
        firestoreRepo.observeAllowlistContacts(currentUserId)
            .map<List<AllowlistContact>, StreamState<List<AllowlistContact>>> { StreamState.Success(it) }
            .catch { err -> emit(StreamState.Error(unwrapFirestoreMsg(err, "Failed to load allowlist"))) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), StreamState.Loading)

    val socialReportsState: StateFlow<StreamState<List<SocialReport>>> =
        firestoreRepo.observeSocialReports(currentUserId)
            .map<List<SocialReport>, StreamState<List<SocialReport>>> { StreamState.Success(it) }
            .catch { err -> emit(StreamState.Error(unwrapFirestoreMsg(err, "Failed to load social reports"))) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), StreamState.Loading)

    val simPlansState: StateFlow<StreamState<List<SimPlan>>> =
        firestoreRepo.observeSimPlans(currentUserId)
            .map<List<SimPlan>, StreamState<List<SimPlan>>> { StreamState.Success(it) }
            .catch { err -> emit(StreamState.Error(unwrapFirestoreMsg(err, "Failed to load SIM plans"))) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), StreamState.Loading)

    private val customVoices: StateFlow<List<VoiceProfile>> =
        firestoreRepo.observeVoiceProfiles(currentUserId)
            .catch { err ->
                handleFlowError("voiceProfiles", err)
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allVoicePresets: StateFlow<List<VoiceStylePreset>> = customVoices
        .map { extras ->
            JarvisVoiceEngine.BUILT_IN_VOICE_PRESETS + extras.map { vp ->
                VoiceStylePreset(
                    id = vp.id,
                    name = vp.name,
                    subtitle = vp.description,
                    pitch = vp.pitch.toFloat(),
                    speechRate = vp.speechRate.toFloat(),
                    isUserOwnVoice = vp.isUserOwnVoice,
                    isCustomAdded = true
                )
            }
        }
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000L),
            JarvisVoiceEngine.BUILT_IN_VOICE_PRESETS
        )

    init {
        viewModelScope.launch {
            try {
                firestoreRepo.ensureUserProfile(currentUserId, userDisplayName)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Failed to initialize user profile", e)
            }
        }
    }

    fun attachHardwareEngines(appContext: Context) {
        if (voiceEngine == null) {
            voiceEngine = JarvisVoiceEngine(
                context = appContext,
                onListeningChanged = { _isListening.value = it },
                onSpeakingChanged = { _isSpeaking.value = it },
                onPartialResult = { _partialSpeech.value = it },
                onFinalSpeechResult = { text, wakeMatched ->
                    _partialSpeech.value = ""
                    onVoiceTranscriptReceived(appContext, text, wakeMatched)
                },
                onSpeechError = { err ->
                    _partialSpeech.value = ""
                    _statusBanner.value = err
                }
            )
        }

        if (batteryMonitor == null) {
            batteryMonitor = BatteryMonitor(
                context = appContext,
                onStatusUpdate = { _batteryStatus.value = it },
                onVoiceAlert = { alertText ->
                    speakOut(alertText, "hi")
                    appendAssistantMessage("Battery Alert: $alertText")
                }
            ).also { it.register() }
        }

        // Sync allowlist/spam cache for CallScreeningService
        viewModelScope.launch {
            allowlistState.collect { state ->
                if (state is StreamState.Success) {
                    val allow = state.data.filter { it.isAllowlisted && !it.isBlockedSpam }.map { it.phoneNumber }.toSet()
                    val spam = state.data.filter { it.isBlockedSpam }.map { it.phoneNumber }.toSet()
                    JarvisCallScreeningService.syncCache(appContext, allow, spam)
                }
            }
        }

        // Sync active voice preset & battery alert setting
        viewModelScope.launch {
            combine(userProfile, allVoicePresets) { profile, presets ->
                profile to presets
            }.collect { (profile, presets) ->
                if (profile != null) {
                    batteryMonitor?.setAlertsEnabled(profile.batteryAlertsEnabled)
                    val chosen = presets.firstOrNull { it.id == profile.preferredVoiceId }
                        ?: presets.first()
                    voiceEngine?.setVoicePreset(chosen)
                }
            }
        }

        refreshHardwareTelemetry(appContext)
    }

    fun refreshHardwareTelemetry(context: Context) {
        _simSlots.value = PhoneCommsHelper.readDualSimSlots(context)
        _deviceContacts.value = PhoneCommsHelper.queryContacts(context)
    }

    fun startVoiceListening(wakeWordMode: Boolean = false) {
        val lang = userProfile.value?.preferredLanguage ?: "auto"
        _statusBanner.value = null
        voiceEngine?.startListening(wakeWordMode = wakeWordMode, languageTag = lang)
    }

    fun stopVoiceListening() {
        voiceEngine?.stopListening()
    }

    fun stopSpeaking() {
        voiceEngine?.stopSpeaking()
    }

    fun speakOut(text: String, langHint: String? = null) {
        val hint = langHint ?: userProfile.value?.preferredLanguage ?: "auto"
        voiceEngine?.speak(text, hint)
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun consumeUnlockPrompt() {
        _unlockPromptTrigger.value = false
    }

    fun onUnlockCompleted(success: Boolean, errorMessage: String? = null) {
        if (success) {
            val ok = "Identity verified. Welcome back!"
            appendAssistantMessage(ok)
            speakOut(ok)
        } else if (!errorMessage.isNullOrBlank()) {
            _statusBanner.value = "Unlock cancelled: $errorMessage"
        }
    }

    private fun onVoiceTranscriptReceived(context: Context, rawText: String, wakeMatched: Boolean) {
        val pending = _pendingConfirmation.value
        if (pending != null) {
            val lower = rawText.lowercase()
            if (lower.contains("yes") || lower.contains("हाँ") || lower.contains("ha") ||
                lower.contains("भेज") || lower.contains("send") || lower.contains("confirm") ||
                lower.contains("kar do") || lower.contains("कर दो")
            ) {
                confirmPendingAction(context)
                return
            } else if (lower.contains("no") || lower.contains("नहीं") || lower.contains("nahi") ||
                lower.contains("cancel") || lower.contains("मत")
            ) {
                dismissPendingAction()
                val msg = "ठीक है, cancel कर दिया गया है।"
                appendAssistantMessage(msg)
                speakOut(msg)
                return
            }
        }

        val wakeEnabled = userProfile.value?.wakeWordEnabled ?: false
        val cleaned = if (wakeMatched) JarvisVoiceEngine.stripWakePhrase(rawText) else rawText
        if (wakeMatched && cleaned.isBlank()) {
            val greet = "जी हाँ, मैं सुन रहा हूँ। बताइए क्या मदद करूँ?"
            appendAssistantMessage(greet)
            speakOut(greet, "hi")
            return
        }
        if (wakeEnabled && wakeMatched) {
            submitUserQuery(context, cleaned)
        } else {
            submitUserQuery(context, cleaned.ifBlank { rawText })
        }
    }

    fun submitUserQuery(context: Context, rawInput: String) {
        val query = rawInput.trim()
        if (query.isBlank()) return

        _chatMessages.value = _chatMessages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            isUser = true,
            text = query
        )

        // Check deterministic device actions first
        when (val action = aiRepo.detectLocalIntent(query)) {
            is AiIntentAction.LockScreen -> {
                if (action.isLock) {
                    val locked = PhoneCommsHelper.lockScreenIfPermitted(context)
                    val reply = if (locked) {
                        "Screen lock कर दिया गया है।"
                    } else {
                        "Screen lock करने के लिए System tab में Device Admin permission चालू करें।"
                    }
                    appendAssistantMessage(reply)
                    speakOut(reply, "hi")
                } else {
                    val msg = "सुरक्षित unlock के लिए कृपया अपना PIN, password या fingerprint सत्यापित करें।"
                    appendAssistantMessage(msg)
                    speakOut(msg, "hi")
                    _unlockPromptTrigger.value = true
                }
                return
            }
            AiIntentAction.CheckBattery -> {
                val b = _batteryStatus.value
                val reply = if (b.percentage >= 0) {
                    "अभी battery ${b.percentage}% है (${b.pluggedSource})। इस session में ${b.dropSinceSessionStart}% कम हुई है।"
                } else {
                    "Battery telemetry reading is initializing."
                }
                appendAssistantMessage(reply)
                speakOut(reply, "hi")
                return
            }
            AiIntentAction.CheckSim -> {
                refreshHardwareTelemetry(context)
                val slots = _simSlots.value
                val plans = (simPlansState.value as? StreamState.Success)?.data.orEmpty()
                val summary = buildSimSummary(slots, plans)
                appendAssistantMessage(summary)
                speakOut(summary)
                return
            }
            AiIntentAction.ShareLiveLocation -> {
                requestLiveLocationShare(context, recipient = "Selected Contact", targetApp = "WhatsApp")
                return
            }
            is AiIntentAction.CallContact -> {
                prepareVoiceCall(context, action.targetNameOrNumber)
                return
            }
            is AiIntentAction.DraftSocialMessage -> {
                prepareSocialMessage(action.platform, action.recipient, action.text)
                return
            }
            is AiIntentAction.SocialReportQuery -> {
                val reportText = buildSocialSummaryText()
                appendAssistantMessage(reportText)
                speakOut(reportText)
                return
            }
            is AiIntentAction.DeleteGalleryItem -> {
                val hint = "Gallery deletion requires selecting the photo/video in Records -> Gallery Control for your security and confirmation."
                appendAssistantMessage(hint)
                speakOut(hint)
                return
            }
            is AiIntentAction.SearchShopping -> {
                runShoppingSearch(action.query)
                val msg = "Searching Amazon, Flipkart & Meesho for ${action.query}. Check the Hub -> Shopping tab for full specs comparison."
                appendAssistantMessage(msg)
                speakOut(msg)
                return
            }
            is AiIntentAction.SearchMovie -> {
                runMovieSearch(action.query)
                val msg = "Searching official OTT & YouTube sources for ${action.query}. Open Hub -> Tickets & Movies."
                appendAssistantMessage(msg)
                speakOut(msg)
                return
            }
            else -> Unit
        }

        // Conversational multilingual streaming with Gemini 3.8 Flash
        val messageId = UUID.randomUUID().toString()
        _chatMessages.value = _chatMessages.value + ChatMessage(
            id = messageId,
            isUser = false,
            text = "",
            isStreaming = true
        )

        val telemetry = buildString {
            val b = _batteryStatus.value
            if (b.percentage >= 0) append("Battery: ${b.percentage}% (${b.pluggedSource}). ")
            val recordsCount = (deleteRecordsState.value as? StreamState.Success)?.data?.size ?: 0
            append("Saved Delete Records: $recordsCount.")
        }

        val lang = userProfile.value?.preferredLanguage ?: "auto"
        viewModelScope.launch {
            _isThinking.value = true
            var latestReply = ""
            try {
                aiRepo.streamConversationalReply(query, lang, telemetry).collect { accumulated ->
                    _isThinking.value = false
                    latestReply = accumulated
                    updateStreamingMessage(messageId, accumulated, isStreaming = true)
                }
                updateStreamingMessage(messageId, latestReply, isStreaming = false)
                if (latestReply.isNotBlank()) {
                    speakOut(latestReply)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI chat failed", e)
                val errText = "AI connection error: ${e.localizedMessage ?: "Please check network & App Check."}"
                updateStreamingMessage(messageId, errText, isStreaming = false)
                _statusBanner.value = errText
            } finally {
                _isThinking.value = false
            }
        }
    }

    private fun updateStreamingMessage(id: String, text: String, isStreaming: Boolean) {
        _chatMessages.value = _chatMessages.value.map { msg ->
            if (msg.id == id) msg.copy(text = text, isStreaming = isStreaming) else msg
        }
    }

    private fun appendAssistantMessage(text: String) {
        _chatMessages.value = _chatMessages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            isUser = false,
            text = text
        )
    }

    // --- Calling & Allowlist ---

    fun prepareVoiceCall(context: Context, queryOrNumber: String) {
        val contacts = PhoneCommsHelper.queryContacts(context, queryOrNumber)
        val matched = contacts.firstOrNull()
        val phone = matched?.phoneNumber ?: queryOrNumber.filter { it.isDigit() || it == '+' }
        val name = matched?.name ?: if (phone.isNotBlank()) "Dial Number" else queryOrNumber

        if (phone.isBlank()) {
            val msg = "Contact '$queryOrNumber' not found or number missing. Grant Contacts permission or enter digits in Comms."
            appendAssistantMessage(msg)
            speakOut(msg)
            return
        }

        _pendingConfirmation.value = PendingConfirmation.VoiceCall(name, phone)
        val prompt = "$name को $phone पर call करूँ? कृपया confirm करें।"
        appendAssistantMessage(prompt)
        speakOut(prompt, "hi")
    }

    fun announceIncomingCallerDemo(context: Context, incomingNumber: String) {
        val contacts = PhoneCommsHelper.queryContacts(context)
        val normalized = JarvisCallScreeningService.normalizePhone(incomingNumber)
        val matchedContact = contacts.firstOrNull {
            JarvisCallScreeningService.normalizePhone(it.phoneNumber) == normalized
        }
        val allowlist = (allowlistState.value as? StreamState.Success)?.data.orEmpty()
        val flaggedSpam = allowlist.firstOrNull {
            JarvisCallScreeningService.normalizePhone(it.phoneNumber) == normalized && it.isBlockedSpam
        }

        val announcement = when {
            flaggedSpam != null -> "Warning! Suspicious spam call from ${flaggedSpam.name} ($incomingNumber). Blocking recommended."
            matchedContact != null -> "Incoming call from ${matchedContact.name}."
            else -> {
                val spacedDigits = incomingNumber.toCharArray().joinToString(" ")
                "Incoming call from unknown number $spacedDigits. Caller is not in your trusted allowlist."
            }
        }
        _statusBanner.value = announcement
        speakOut(announcement, "en")
    }

    fun addAllowlistEntry(name: String, phone: String, relationship: String, isBlockedSpam: Boolean) {
        viewModelScope.launch {
            try {
                firestoreRepo.saveAllowlistContact(
                    name = name,
                    phoneNumber = phone,
                    relationship = relationship,
                    isAllowlisted = !isBlockedSpam,
                    isBlockedSpam = isBlockedSpam
                )
                _statusBanner.value = if (isBlockedSpam) "Added to Spam Blocklist" else "Added to Trusted Allowlist"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _statusBanner.value = e.localizedMessage
            }
        }
    }

    fun toggleAllowlistSpam(contact: AllowlistContact, isBlockedSpam: Boolean) {
        viewModelScope.launch {
            try {
                firestoreRepo.updateAllowlistStatus(contact.id, isAllowlisted = !isBlockedSpam, isBlockedSpam = isBlockedSpam)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _statusBanner.value = e.localizedMessage
            }
        }
    }

    fun deleteAllowlistEntry(contactId: String) {
        viewModelScope.launch {
            try {
                firestoreRepo.deleteAllowlistContact(contactId)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _statusBanner.value = e.localizedMessage
            }
        }
    }

    // --- Messaging ---

    fun prepareSocialMessage(platform: String, recipient: String, messageText: String) {
        if (messageText.isBlank()) {
            _statusBanner.value = "Please enter or dictate a message first."
            return
        }
        _pendingConfirmation.value = PendingConfirmation.SocialMessage(platform, recipient, messageText)
        val speakText = "आपका $platform message है: $messageText। क्या इसे भेज दूँ?"
        appendAssistantMessage(speakText)
        speakOut(speakText, "hi")
    }

    // --- Live Location ---

    fun requestLiveLocationShare(context: Context, recipient: String, targetApp: String) {
        viewModelScope.launch {
            _isThinking.value = true
            val loc = PhoneCommsHelper.getCurrentLocation(context)
            _isThinking.value = false
            if (loc == null) {
                val msg = "Live location प्राप्त नहीं हो सकी। कृपया Location permission और GPS चालू करें।"
                _statusBanner.value = msg
                speakOut(msg, "hi")
            } else {
                _pendingConfirmation.value = PendingConfirmation.LocationShare(
                    latitude = loc.latitude,
                    longitude = loc.longitude,
                    recipient = recipient.ifBlank { "Chosen Contact" },
                    targetApp = targetApp.ifBlank { "WhatsApp" }
                )
                val msg = "Live location तैयार है (${"%.4f".format(loc.latitude)}, ${"%.4f".format(loc.longitude)})। क्या इसे $targetApp पर भेज दूँ?"
                appendAssistantMessage(msg)
                speakOut(msg, "hi")
            }
        }
    }

    // --- Delete History & Media Control ---

    fun requestMediaDeletionWithConfirmation(title: String, itemType: String, sourceApp: String, uri: Uri?) {
        _pendingConfirmation.value = PendingConfirmation.DeleteItem(
            title = title,
            itemType = itemType,
            sourceApp = sourceApp,
            uriString = uri?.toString()
        )
        val msg = "क्या आप $sourceApp से '$title' delete करना चाहते हैं? कृपया confirm करें।"
        speakOut(msg, "hi")
    }

    fun logManualDeleteRecord(title: String, itemType: String, sourceApp: String, details: String) {
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(now))
                firestoreRepo.addDeleteRecord(title, itemType, sourceApp, details, dateKey, now)
                _statusBanner.value = "Permanent delete activity record saved for $dateKey"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _statusBanner.value = e.localizedMessage
            }
        }
    }

    fun updateOldDeleteRecord(record: DeleteRecord, newTitle: String, newDetails: String) {
        viewModelScope.launch {
            try {
                firestoreRepo.updateDeleteRecordDetails(record, newTitle, newDetails)
                _statusBanner.value = "Record updated permanently."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _statusBanner.value = e.localizedMessage
            }
        }
    }

    fun clearPendingMediaDeleteIntent() {
        _pendingMediaDeleteUri.value = null
    }

    // --- Vision ---

    fun analyzeVisionImage(bitmap: Bitmap) {
        viewModelScope.launch {
            _visionState.value = FeatureState.Loading
            _isThinking.value = true
            try {
                val lang = userProfile.value?.preferredLanguage ?: "auto"
                val result = aiRepo.analyzeVisionFrame(bitmap, lang)
                _visionState.value = FeatureState.Success(result)
                val summarySpeech = "${result.appearanceSummary} ${result.outfitAndColors} ${result.musicReason}"
                speakOut(summarySpeech)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Vision error", e)
                _visionState.value = FeatureState.Error(e.localizedMessage ?: "Vision analysis failed")
            } finally {
                _isThinking.value = false
            }
        }
    }

    // --- Shopping ---

    fun runShoppingSearch(query: String) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _shoppingState.value = FeatureState.Loading
            _isThinking.value = true
            try {
                val products = aiRepo.searchShoppingProducts(query)
                _shoppingState.value = FeatureState.Success(products)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _shoppingState.value = FeatureState.Error(e.localizedMessage ?: "Shopping search failed")
            } finally {
                _isThinking.value = false
            }
        }
    }

    fun prepareShoppingCheckout(
        product: ShoppingProduct,
        address: String,
        phone: String,
        paymentMethod: String
    ) {
        _pendingConfirmation.value = PendingConfirmation.ShoppingOrder(
            product = product,
            deliveryAddress = address.ifBlank { "Enter on official merchant checkout" },
            contactPhone = phone.ifBlank { "Enter on official merchant checkout" },
            paymentMethod = paymentMethod,
            finalPriceSummary = "${product.priceInr} (${product.deliveryAndTaxes})"
        )
    }

    // --- Movies & Tickets ---

    fun runMovieSearch(query: String) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _movieState.value = FeatureState.Loading
            _isThinking.value = true
            try {
                val res = aiRepo.searchOfficialMovie(query)
                _movieState.value = FeatureState.Success(res)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _movieState.value = FeatureState.Error(e.localizedMessage ?: "Movie lookup failed")
            } finally {
                _isThinking.value = false
            }
        }
    }

    fun runTicketPlanning(bookingType: String, query: String, date: String) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _ticketState.value = FeatureState.Loading
            _isThinking.value = true
            try {
                val options = aiRepo.planTicketBooking(bookingType, query, date)
                _ticketState.value = FeatureState.Success(options)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ticketState.value = FeatureState.Error(e.localizedMessage ?: "Ticket lookup failed")
            } finally {
                _isThinking.value = false
            }
        }
    }

    fun prepareTicketBooking(option: TicketBookingOption, guestCount: Int) {
        _pendingConfirmation.value = PendingConfirmation.TicketBooking(option, guestCount.coerceAtLeast(1))
    }

    // --- Social Reports & SIM Plans ---

    fun saveSocialReport(report: SocialReport) {
        viewModelScope.launch {
            try {
                firestoreRepo.saveSocialReport(report)
                _statusBanner.value = "Official snapshot saved to permanent report ledger."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _statusBanner.value = e.localizedMessage
            }
        }
    }

    fun buildSocialSummaryText(): String {
        val list = (socialReportsState.value as? StreamState.Success)?.data.orEmpty()
        if (list.isEmpty()) {
            return "अभी कोई official social media snapshot saved नहीं है। Hub -> Social Report में जाकर अपना verified data जोड़ें।"
        }
        val totalEarnings = list.sumOf { it.earningsInr }
        val totalFollowers = list.groupBy { it.platform }.values.sumOf { grp -> grp.firstOrNull()?.totalFollowers ?: 0L }
        val totalViews = list.sumOf { it.viewsOrImpressions }
        return "आपके saved official social reports के अनुसार कुल followers $totalFollowers हैं, total views $totalViews हैं, और कुल कमाई ₹${"%.2f".format(totalEarnings)} है।"
    }

    fun saveSimPlan(plan: SimPlan) {
        viewModelScope.launch {
            try {
                firestoreRepo.saveSimPlan(plan)
                _statusBanner.value = "SIM ${plan.simSlot} plan updated."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _statusBanner.value = e.localizedMessage
            }
        }
    }

    // --- Voice & Preferences ---

    fun selectVoicePreset(preset: VoiceStylePreset) {
        voiceEngine?.setVoicePreset(preset)
        viewModelScope.launch {
            try {
                firestoreRepo.updateUserPreferences(currentUserId, preferredVoiceId = preset.id)
                speakOut("Voice style switched to ${preset.name}. Systems nominal.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _statusBanner.value = e.localizedMessage
            }
        }
    }

    fun addCustomVoiceProfile(name: String, description: String, pitch: Double, rate: Double, isUserOwn: Boolean, consent: Boolean) {
        viewModelScope.launch {
            try {
                firestoreRepo.addVoiceProfile(name, description, pitch, rate, isUserOwn, consent)
                _statusBanner.value = "New voice profile '$name' added."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _statusBanner.value = e.localizedMessage
            }
        }
    }

    fun updatePreferences(
        customVoiceConsent: Boolean? = null,
        wakeWordEnabled: Boolean? = null,
        batteryAlertsEnabled: Boolean? = null,
        preferredLanguage: String? = null
    ) {
        viewModelScope.launch {
            try {
                firestoreRepo.updateUserPreferences(
                    userId = currentUserId,
                    customUserVoiceConsent = customVoiceConsent,
                    wakeWordEnabled = wakeWordEnabled,
                    batteryAlertsEnabled = batteryAlertsEnabled,
                    preferredLanguage = preferredLanguage
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _statusBanner.value = e.localizedMessage
            }
        }
    }

    // --- Confirmation Execution ---

    fun confirmPendingAction(context: Context) {
        val pending = _pendingConfirmation.value ?: return
        _pendingConfirmation.value = null

        when (pending) {
            is PendingConfirmation.VoiceCall -> {
                PhoneCommsHelper.placeCallConfirmed(context, pending.phoneNumber)
                appendAssistantMessage("Calling ${pending.contactName} (${pending.phoneNumber})...")
            }
            is PendingConfirmation.SocialMessage -> {
                if (pending.platform.equals("SMS", ignoreCase = true)) {
                    val ok = PhoneCommsHelper.sendSmsConfirmed(context, pending.recipient, pending.messageText)
                    appendAssistantMessage(if (ok) "SMS dispatched." else "Could not dispatch SMS directly; opened Messages app.")
                } else {
                    PhoneCommsHelper.shareToSocialApp(context, pending.platform, pending.messageText, pending.recipient)
                    appendAssistantMessage("Opened ${pending.platform} with your confirmed message.")
                }
            }
            is PendingConfirmation.LocationShare -> {
                val mapsUrl = "https://maps.google.com/?q=${pending.latitude},${pending.longitude}"
                val msg = "My Live Location (shared via Trony AI Jarvis): $mapsUrl"
                if (pending.targetApp.equals("SMS", ignoreCase = true)) {
                    PhoneCommsHelper.sendSmsConfirmed(context, pending.recipient, msg)
                } else {
                    PhoneCommsHelper.shareToSocialApp(context, pending.targetApp, msg)
                }
                appendAssistantMessage("Live location shared via ${pending.targetApp}.")
            }
            is PendingConfirmation.DeleteItem -> {
                val uri = pending.uriString?.toUri()
                if (uri != null) {
                    _pendingMediaDeleteUri.value = uri to pending.title
                }
                logManualDeleteRecord(
                    title = pending.title,
                    itemType = pending.itemType,
                    sourceApp = pending.sourceApp,
                    details = "User confirmed deletion via Trony AI Jarvis"
                )
                appendAssistantMessage("Deletion confirmed and logged permanently in Delete History.")
            }
            is PendingConfirmation.ShoppingOrder -> {
                PhoneCommsHelper.openUrl(context, pending.product.searchUrl)
                appendAssistantMessage("Opened official ${pending.product.platform} page. Complete payment securely with your own PIN/CVV/OTP.")
            }
            is PendingConfirmation.TicketBooking -> {
                PhoneCommsHelper.openUrl(context, pending.option.officialUrl)
                appendAssistantMessage("Opened official ${pending.option.officialPlatformName} booking portal.")
            }
        }
    }

    fun dismissPendingAction() {
        _pendingConfirmation.value = null
    }

    private fun buildSimSummary(slots: List<SimSlotInfo>, plans: List<SimPlan>): String {
        if (slots.isEmpty() && plans.isEmpty()) {
            return "SIM details reading requires Phone State permission. You can also save SIM 1 & SIM 2 recharge plans in System -> SIM Checker."
        }
        return buildString {
            if (slots.isNotEmpty()) {
                slots.forEach { slot ->
                    append("SIM ${slot.slotIndex}: ${slot.carrierName} (${slot.countryIso}). ")
                }
            }
            plans.forEach { plan ->
                append("SIM ${plan.simSlot} Plan: ${plan.planName} (₹${plan.planPriceInr.toInt()}), ${plan.remainingDataGb} GB left, expires ${plan.expiryDateKey}. ")
            }
        }
    }

    private fun unwrapFirestoreMsg(error: Throwable, fallback: String): String {
        val fs = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (fs == null && error is CancellationException) throw error
        val root = fs ?: error
        Log.w(TAG, fallback, root)
        return root.message ?: fallback
    }

    private fun handleFlowError(name: String, error: Throwable) {
        val fs = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (fs == null && error is CancellationException) throw error
        Log.w(TAG, "Stream $name error", fs ?: error)
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngine?.destroy()
        batteryMonitor?.unregister()
    }

    private companion object {
        const val TAG = "JarvisViewModel"
    }
}
