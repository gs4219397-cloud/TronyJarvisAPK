package com.example.system

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.model.VoiceStylePreset
import java.util.Locale
import java.util.UUID

class JarvisVoiceEngine(
    private val context: Context,
    private val onListeningChanged: (Boolean) -> Unit,
    private val onSpeakingChanged: (Boolean) -> Unit,
    private val onPartialResult: (String) -> Unit,
    private val onFinalSpeechResult: (String, Boolean) -> Unit,
    private val onSpeechError: (String) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var activePreset: VoiceStylePreset = BUILT_IN_VOICE_PRESETS.first()
    private var wakeWordOnlyMode = false
    private var pendingSpeech: Pair<String, String>? = null

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        onSpeakingChanged(true)
                    }

                    override fun onDone(utteranceId: String?) {
                        onSpeakingChanged(false)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        onSpeakingChanged(false)
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        onSpeakingChanged(false)
                    }
                })
                pendingSpeech?.let { (queuedText, queuedHint) ->
                    pendingSpeech = null
                    speak(queuedText, queuedHint)
                }
            } else {
                Log.e(TAG, "TextToSpeech init failed with status $status")
            }
        }
    }

    fun setVoicePreset(preset: VoiceStylePreset) {
        activePreset = preset
    }

    fun speak(text: String, explicitLanguageHint: String = "auto") {
        if (text.isBlank()) return
        if (!isTtsReady) {
            pendingSpeech = text to explicitLanguageHint
            return
        }
        val locale = detectLocale(text, explicitLanguageHint)
        val langResult = tts?.setLanguage(locale)
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.forLanguageTag("en-IN"))
        }
        tts?.setPitch(activePreset.pitch)
        tts?.setSpeechRate(activePreset.speechRate)
        val utteranceId = "jarvis_${UUID.randomUUID()}"
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stopSpeaking() {
        tts?.stop()
        onSpeakingChanged(false)
    }

    fun startListening(wakeWordMode: Boolean = false, languageTag: String = "auto") {
        wakeWordOnlyMode = wakeWordMode
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onSpeechError("Speech recognition service is not available on this device.")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    onListeningChanged(true)
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    onListeningChanged(false)
                }

                override fun onError(error: Int) {
                    onListeningChanged(false)
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                        SpeechRecognizer.ERROR_CLIENT -> "Speech client error"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
                        SpeechRecognizer.ERROR_NETWORK -> "Network error during speech recognition"
                        SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please speak clearly."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy, please wait"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected."
                        else -> "Speech recognition error ($error)"
                    }
                    onSpeechError(msg)
                }

                override fun onResults(results: Bundle?) {
                    onListeningChanged(false)
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull().orEmpty().trim()
                    if (text.isNotEmpty()) {
                        val wakeMatched = containsWakePhrase(text)
                        onFinalSpeechResult(text, wakeMatched)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val partial = matches?.firstOrNull().orEmpty()
                    if (partial.isNotBlank()) {
                        onPartialResult(partial)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            val speechLang = when (languageTag) {
                "hi" -> "hi-IN"
                "bn" -> "bn-IN"
                "ta" -> "ta-IN"
                "en" -> "en-IN"
                else -> "en-IN"
            }
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, speechLang)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, speechLang)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            onListeningChanged(false)
            onSpeechError("Could not start voice recognition: ${e.localizedMessage ?: "Service unavailable"}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {
        }
        onListeningChanged(false)
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    private fun detectLocale(text: String, hint: String): Locale {
        if (hint == "hi") return Locale.forLanguageTag("hi-IN")
        if (hint == "bn") return Locale.forLanguageTag("bn-IN")
        if (hint == "ta") return Locale.forLanguageTag("ta-IN")
        if (hint == "en") return Locale.forLanguageTag("en-IN")

        val hasDevanagari = text.any { it in '\u0900'..'\u097F' }
        val hasBengali = text.any { it in '\u0980'..'\u09FF' }
        val hasTamil = text.any { it in '\u0B80'..'\u0BFF' }
        return when {
            hasDevanagari -> Locale.forLanguageTag("hi-IN")
            hasBengali -> Locale.forLanguageTag("bn-IN")
            hasTamil -> Locale.forLanguageTag("ta-IN")
            else -> Locale.forLanguageTag("en-IN")
        }
    }

    companion object {
        private const val TAG = "JarvisVoiceEngine"

        fun containsWakePhrase(spoken: String): Boolean {
            val lower = spoken.lowercase()
            return lower.contains("hi jarvis") ||
                lower.contains("hey jarvis") ||
                lower.contains("hi tony jarvis") ||
                lower.contains("tony jarvis") ||
                lower.contains("tony ai jarvis") ||
                lower.contains("हाय जार्विस") ||
                lower.contains("हाय टोनी जार्विस")
        }

        fun stripWakePhrase(spoken: String): String {
            return spoken
                .replace(Regex("(?i)(hi tony ai jarvis|hi tony jarvis|tony ai jarvis|tony jarvis|hi jarvis|hey jarvis)"), "")
                .trim()
        }

        val BUILT_IN_VOICE_PRESETS: List<VoiceStylePreset> = listOf(
            VoiceStylePreset(
                id = "jarvis_classic",
                name = "J.A.R.V.I.S. Classic",
                subtitle = "Calm, composed futuristic butler cadence",
                pitch = 0.94f,
                speechRate = 1.0f
            ),
            VoiceStylePreset(
                id = "tony_stark_tech",
                name = "Stark Architect",
                subtitle = "Sharp, witty, energetic inventor style",
                pitch = 1.04f,
                speechRate = 1.12f
            ),
            VoiceStylePreset(
                id = "iron_core_deep",
                name = "Armored Core Deep",
                subtitle = "Deep resonant armored command voice",
                pitch = 0.72f,
                speechRate = 0.92f
            ),
            VoiceStylePreset(
                id = "titan_gamma",
                name = "Gamma Titan",
                subtitle = "Ultra-deep powerhouse inspired by heavy-hitter heroes",
                pitch = 0.58f,
                speechRate = 0.85f
            ),
            VoiceStylePreset(
                id = "krypton_sentinel",
                name = "Krypton Sentinel",
                subtitle = "Noble, steady, reassuring baritone",
                pitch = 0.84f,
                speechRate = 0.98f
            ),
            VoiceStylePreset(
                id = "friday_neural",
                name = "F.R.I.D.A.Y. Neural",
                subtitle = "Crisp, bright futuristic AI telemetry tone",
                pitch = 1.16f,
                speechRate = 1.06f
            ),
            VoiceStylePreset(
                id = "serene_horizon",
                name = "Serene Horizon",
                subtitle = "Calm, gentle, soothing conversational flow",
                pitch = 0.98f,
                speechRate = 0.88f
            ),
            VoiceStylePreset(
                id = "hyper_spark",
                name = "Hyper Spark",
                subtitle = "Fast, upbeat, high-energy companion",
                pitch = 1.18f,
                speechRate = 1.18f
            ),
            VoiceStylePreset(
                id = "warm_companion",
                name = "Warm Companion",
                subtitle = "Friendly, natural, approachable human warmth",
                pitch = 1.06f,
                speechRate = 0.97f
            ),
            VoiceStylePreset(
                id = "user_own_voice",
                name = "My Own Voice Profile",
                subtitle = "Enabled only with your explicit consent & device voice engine",
                pitch = 1.0f,
                speechRate = 1.0f,
                isUserOwnVoice = true
            )
        )
    }
}
