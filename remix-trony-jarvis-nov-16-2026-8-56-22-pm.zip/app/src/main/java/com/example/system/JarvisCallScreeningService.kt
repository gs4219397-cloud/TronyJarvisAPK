package com.example.system

import android.content.Context
import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import android.util.Log
import androidx.core.content.edit

/**
 * CallScreeningService evaluates incoming calls against the user's cached allowlist and spam list.
 * Requires the user to designate Trony Jarvis as the Caller ID & Spam App in Android settings.
 */
class JarvisCallScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        val handle = callDetails.handle
        val phoneNumber = handle?.schemeSpecificPart ?: ""
        val normalized = normalizePhone(phoneNumber)

        val prefs = applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val allowSet = prefs.getStringSet(KEY_ALLOWLIST, emptySet()) ?: emptySet()
        val spamSet = prefs.getStringSet(KEY_SPAMLIST, emptySet()) ?: emptySet()

        val isAllowlisted = normalized.isNotEmpty() && allowSet.any { normalizePhone(it) == normalized }
        val isSpam = normalized.isNotEmpty() && spamSet.any { normalizePhone(it) == normalized }

        val responseBuilder = CallResponse.Builder()
        if (isSpam && !isAllowlisted) {
            Log.i(TAG, "Rejecting flagged spam caller: $phoneNumber")
            responseBuilder
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipNotification(false)
        } else {
            responseBuilder
                .setDisallowCall(false)
                .setRejectCall(false)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                responseBuilder.setSilenceCall(false)
            }
        }

        // Save last screened caller for in-app announcement
        prefs.edit {
            putString(KEY_LAST_CALLER, phoneNumber)
            putLong(KEY_LAST_CALLER_TIME, System.currentTimeMillis())
        }

        respondToCall(callDetails, responseBuilder.build())
    }

    companion object {
        private const val TAG = "JarvisCallScreening"
        const val PREFS_NAME = "jarvis_call_screening_cache"
        const val KEY_ALLOWLIST = "allowlist_numbers"
        const val KEY_SPAMLIST = "spam_numbers"
        const val KEY_LAST_CALLER = "last_caller_number"
        const val KEY_LAST_CALLER_TIME = "last_caller_time"

        fun normalizePhone(raw: String): String {
            val digits = raw.filter { it.isDigit() }
            return if (digits.length > 10) digits.takeLast(10) else digits
        }

        fun syncCache(context: Context, allowNumbers: Set<String>, spamNumbers: Set<String>) {
            context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit {
                    putStringSet(KEY_ALLOWLIST, allowNumbers)
                    putStringSet(KEY_SPAMLIST, spamNumbers)
                }
        }
    }
}
