package com.example.system

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.fragment.app.FragmentActivity
import com.example.data.model.DeviceContact
import com.example.data.model.SimSlotInfo
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

object PhoneCommsHelper {

    fun hasPermission(context: Context, permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    fun queryContacts(context: Context, filterQuery: String = ""): List<DeviceContact> {
        if (!hasPermission(context, Manifest.permission.READ_CONTACTS)) return emptyList()
        val list = mutableListOf<DeviceContact>()
        val seenNumbers = mutableSetOf<String>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = if (filterQuery.isNotBlank()) {
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ? OR ${ContactsContract.CommonDataKinds.Phone.NUMBER} LIKE ?"
        } else null
        val args = if (filterQuery.isNotBlank()) {
            arrayOf("%$filterQuery%", "%$filterQuery%")
        } else null

        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            selection,
            args,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
        )?.use { cursor ->
            val nameIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext() && list.size < 100) {
                val name = cursor.getString(nameIdx)?.trim().orEmpty()
                val num = cursor.getString(numIdx)?.trim().orEmpty()
                if (name.isNotEmpty() && num.isNotEmpty() && seenNumbers.add(num)) {
                    list.add(DeviceContact(name, num))
                }
            }
        }
        return list
    }

    private fun safeStartActivity(context: Context, intent: Intent): Boolean {
        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun openDialerWithNumber(context: Context, phoneNumber: String) {
        val intent = Intent(Intent.ACTION_DIAL, "tel:${Uri.encode(phoneNumber)}".toUri()).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        safeStartActivity(context, intent)
    }

    @SuppressLint("MissingPermission")
    fun placeCallConfirmed(context: Context, phoneNumber: String) {
        if (hasPermission(context, Manifest.permission.CALL_PHONE)) {
            val intent = Intent(Intent.ACTION_CALL, "tel:${Uri.encode(phoneNumber)}".toUri()).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (!safeStartActivity(context, intent)) {
                openDialerWithNumber(context, phoneNumber)
            }
        } else {
            openDialerWithNumber(context, phoneNumber)
        }
    }

    fun sendSmsConfirmed(context: Context, phoneNumber: String, message: String): Boolean {
        return try {
            val smsManager: SmsManager? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            if (hasPermission(context, Manifest.permission.SEND_SMS) && phoneNumber.isNotBlank() && smsManager != null) {
                val parts = smsManager.divideMessage(message)
                smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null)
                true
            } else {
                val intent = Intent(Intent.ACTION_SENDTO, "smsto:${Uri.encode(phoneNumber)}".toUri()).apply {
                    putExtra("sms_body", message)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                safeStartActivity(context, intent)
            }
        } catch (_: Exception) {
            false
        }
    }

    fun shareToSocialApp(context: Context, platform: String, message: String, phoneHint: String = "") {
        val encodedMsg = Uri.encode(message)
        val pkg = when (platform.lowercase()) {
            "whatsapp" -> "com.whatsapp"
            "messenger" -> "com.facebook.orca"
            "facebook" -> "com.facebook.katana"
            "instagram" -> "com.instagram.android"
            "x", "twitter" -> "com.twitter.android"
            else -> null
        }

        if (platform.equals("WhatsApp", ignoreCase = true) && phoneHint.isNotBlank()) {
            val cleanDigits = phoneHint.filter { it.isDigit() }
            val waUri = "https://wa.me/$cleanDigits?text=$encodedMsg".toUri()
            val waIntent = Intent(Intent.ACTION_VIEW, waUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (safeStartActivity(context, waIntent)) return
        }

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
            if (pkg != null) setPackage(pkg)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (!safeStartActivity(context, shareIntent)) {
            val chooser = Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, message)
                },
                "Share via $platform"
            ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            safeStartActivity(context, chooser)
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(context: Context): Location? {
        val hasFine = hasPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
        val hasCoarse = hasPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (!hasFine && !hasCoarse) return null

        val client = LocationServices.getFusedLocationProviderClient(context)
        val priority = if (hasFine) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY
        return suspendCancellableCoroutine { cont ->
            client.getCurrentLocation(priority, null)
                .addOnSuccessListener { loc ->
                    if (cont.isActive) cont.resume(loc)
                }
                .addOnFailureListener {
                    if (cont.isActive) cont.resume(null)
                }
        }
    }

    @SuppressLint("MissingPermission")
    fun readDualSimSlots(context: Context): List<SimSlotInfo> {
        if (!hasPermission(context, Manifest.permission.READ_PHONE_STATE)) return emptyList()
        return try {
            val subManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            val subs = subManager.activeSubscriptionInfoList.orEmpty()
            subs.map { info ->
                SimSlotInfo(
                    slotIndex = info.simSlotIndex + 1,
                    carrierName = info.carrierName?.toString().orEmpty().ifBlank { "Unknown Carrier" },
                    displayName = info.displayName?.toString().orEmpty().ifBlank { "SIM ${info.simSlotIndex + 1}" },
                    countryIso = info.countryIso?.uppercase().orEmpty().ifBlank { "IN" },
                    isRoaming = info.dataRoaming == SubscriptionManager.DATA_ROAMING_ENABLE
                )
            }.sortedBy { it.slotIndex }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun openCarrierAppOrPortal(context: Context, operatorName: String) {
        val lower = operatorName.lowercase()
        val (pkg, fallbackUrl) = when {
            lower.contains("jio") -> "com.jio.myjio" to "https://www.jio.com/selfcare/plans/mobility/prepaid-plans-home/"
            lower.contains("airtel") -> "com.myairtelapp" to "https://www.airtel.in/recharge-online"
            lower.contains("vi") || lower.contains("vodafone") || lower.contains("idea") ->
                "com.mventus.selfcare.activity" to "https://www.myvi.in/prepaid/best-prepaid-plans"
            lower.contains("bsnl") -> "in.bsnl.selfcare" to "https://portal2.bsnl.in/myportal/"
            else -> null to "https://www.google.com/search?q=${Uri.encode("$operatorName recharge plans")}"
        }
        if (pkg != null) {
            val launch = context.packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                return
            }
        }
        openUrl(context, fallbackUrl)
    }

    fun openUrl(context: Context, url: String) {
        val intent = Intent(Intent.ACTION_VIEW, url.toUri()).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        safeStartActivity(context, intent)
    }

    fun openYouTubeSearch(context: Context, query: String) {
        val url = "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
        openUrl(context, url)
    }

    fun isDeviceAdminActive(context: Context): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(context, JarvisDeviceAdminReceiver::class.java)
        return dpm.isAdminActive(admin)
    }

    fun requestDeviceAdminActivation(context: Context) {
        val admin = ComponentName(context, JarvisDeviceAdminReceiver::class.java)
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Enables Trony AI Jarvis to lock your screen when you say 'Tony AI JARVIS, lock kar do'."
            )
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        safeStartActivity(context, intent)
    }

    fun lockScreenIfPermitted(context: Context): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(context, JarvisDeviceAdminReceiver::class.java)
        return if (dpm.isAdminActive(admin)) {
            dpm.lockNow()
            true
        } else {
            false
        }
    }

    fun promptSecureBiometricUnlock(
        activity: FragmentActivity,
        onAuthenticated: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onAuthenticated()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    onError(errString.toString())
                }
            }
        )

        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("TRONY AI JARVIS // Secure Unlock")
            .setSubtitle("Verify with Biometrics, PIN, Pattern, or Password")
            .setAllowedAuthenticators(authenticators)
            .build()
        prompt.authenticate(promptInfo)
    }

    fun buildMediaDeletePendingIntent(context: Context, uri: Uri): PendingIntent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                MediaStore.createDeleteRequest(context.contentResolver, listOf(uri))
            } catch (_: Exception) {
                null
            }
        } else {
            null
        }
    }

    fun openCallScreeningSettings(context: Context) {
        val intent = Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        safeStartActivity(context, intent)
    }
}
