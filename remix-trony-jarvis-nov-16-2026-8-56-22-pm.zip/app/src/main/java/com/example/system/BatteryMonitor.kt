package com.example.system

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.core.content.ContextCompat
import com.example.data.model.BatteryStatus

class BatteryMonitor(
    private val context: Context,
    private val onStatusUpdate: (BatteryStatus) -> Unit,
    private val onVoiceAlert: (String) -> Unit
) {
    private var initialPercentage: Int? = null
    private var lastChargingState: Boolean? = null
    private var alerted20 = false
    private var alerted10 = false
    private var alerted50Charging = false
    private var alerted100Charging = false
    private var lastAnnouncementText = ""
    private var alertsEnabled = true
    private var isRegistered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent == null) return
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> handleBatteryChanged(intent)
                Intent.ACTION_POWER_CONNECTED -> {
                    val msg = "Battery charge पर लग गई है।"
                    triggerAlert(msg)
                    alerted50Charging = false
                    alerted100Charging = false
                }
                Intent.ACTION_POWER_DISCONNECTED -> {
                    alerted50Charging = false
                    alerted100Charging = false
                }
            }
        }
    }

    fun setAlertsEnabled(enabled: Boolean) {
        alertsEnabled = enabled
    }

    fun register() {
        if (isRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        val sticky = ContextCompat.registerReceiver(
            context,
            receiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        isRegistered = true
        sticky?.let { handleBatteryChanged(it) }
    }

    fun unregister() {
        if (!isRegistered) return
        try {
            context.unregisterReceiver(receiver)
        } catch (_: IllegalArgumentException) {
        }
        isRegistered = false
    }

    private fun handleBatteryChanged(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val pct = if (level >= 0) (level * 100) / scale else -1
        if (pct < 0) return

        if (initialPercentage == null) {
            initialPercentage = pct
        }

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val pluggedSource = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC Fast Charger"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB Cable"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless Charger"
            else -> if (isCharging) "Charging" else "Battery"
        }

        if (lastChargingState != null && lastChargingState != isCharging && isCharging) {
            triggerAlert("Battery charge पर लग गई है।")
        }
        lastChargingState = isCharging

        // Anti-spam threshold logic
        if (!isCharging) {
            if (pct > 25) alerted20 = false
            if (pct > 15) alerted10 = false

            if (pct <= 10 && !alerted10) {
                alerted10 = true
                alerted20 = true
                triggerAlert("Battery 10% है, जल्दी charge पर लगाओ।")
            } else if (pct in 11..20 && !alerted20) {
                alerted20 = true
                triggerAlert("Battery 20% है, फोन charge पर लगा दो।")
            }
        } else {
            if (pct < 45) alerted50Charging = false
            if (pct < 95) alerted100Charging = false

            if (pct >= 100 && !alerted100Charging) {
                alerted100Charging = true
                triggerAlert("Battery 100% हो गई है।")
            } else if (pct in 50..55 && !alerted50Charging) {
                alerted50Charging = true
                triggerAlert("50% charge हो गया।")
            }
        }

        val drop = ((initialPercentage ?: pct) - pct).coerceAtLeast(0)
        onStatusUpdate(
            BatteryStatus(
                percentage = pct,
                isCharging = isCharging,
                pluggedSource = pluggedSource,
                dropSinceSessionStart = drop,
                lastAnnouncement = lastAnnouncementText
            )
        )
    }

    private fun triggerAlert(message: String) {
        lastAnnouncementText = message
        if (alertsEnabled) {
            onVoiceAlert(message)
        }
    }
}
