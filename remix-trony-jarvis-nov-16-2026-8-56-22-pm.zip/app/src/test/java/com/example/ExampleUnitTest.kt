package com.example

import com.example.data.repository.AiIntentAction
import com.example.data.repository.JarvisAiRepository
import com.example.system.JarvisCallScreeningService
import com.example.system.JarvisVoiceEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun wakePhraseDetection_matchesRequiredPhrases() {
        assertTrue(JarvisVoiceEngine.containsWakePhrase("Hi JARVIS what is my battery"))
        assertTrue(JarvisVoiceEngine.containsWakePhrase("Hi Tony JARVIS मेरी live location भेज दो"))
        assertFalse(JarvisVoiceEngine.containsWakePhrase("Hello friend how are you"))
    }

    @Test
    fun phoneNormalization_extractsLastTenDigits() {
        assertEquals("9876543210", JarvisCallScreeningService.normalizePhone("+91 98765-43210"))
        assertEquals("9876543210", JarvisCallScreeningService.normalizePhone("09876543210"))
    }

    @Test
    fun localIntentDetection_routesCoreCommands() {
        val repo = JarvisAiRepository()
        assertTrue(repo.detectLocalIntent("Tony AI JARVIS, lock कर दो") is AiIntentAction.LockScreen)
        assertTrue(repo.detectLocalIntent("Tony JARVIS, मेरी live location भेज दो") is AiIntentAction.ShareLiveLocation)
        assertTrue(repo.detectLocalIntent("₹20,000 के अंदर phone खोजो") is AiIntentAction.SearchShopping)
        assertTrue(repo.detectLocalIntent("Gallery की पहली photo delete करो") is AiIntentAction.DeleteGalleryItem)
    }
}
