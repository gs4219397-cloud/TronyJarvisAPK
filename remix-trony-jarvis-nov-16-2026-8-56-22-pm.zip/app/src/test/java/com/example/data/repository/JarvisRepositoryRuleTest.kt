package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.SimPlan
import com.example.data.model.SocialReport
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class JarvisRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun deleteRecord_authenticatedOwner_createsReadsAndUpdates() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repo = JarvisFirestoreRepository(firestore)
        val uniqueTitle = "Photo_${UUID.randomUUID().toString().take(8)}.jpg"

        val id = withTimeout(TIMEOUT_MS) {
            repo.addDeleteRecord(
                itemTitle = uniqueTitle,
                itemType = "photo",
                sourceApp = "Gallery",
                details = "Initial deletion log",
                dateKey = "2026-11-13",
                deletedAtEpochMs = System.currentTimeMillis()
            )
        }
        assertTrue(id.isNotBlank())

        val records = withTimeout(TIMEOUT_MS) {
            repo.observeDeleteRecords(uid).first { list -> list.any { it.id == id } }
        }
        val created = records.first { it.id == id }
        assertEquals(uniqueTitle, created.itemTitle)

        withTimeout(TIMEOUT_MS) {
            repo.updateDeleteRecordDetails(created, uniqueTitle, "Updated after 8 days")
        }

        val updated = withTimeout(TIMEOUT_MS) {
            repo.observeDeleteRecords(uid).first { list ->
                list.any { it.id == id && it.details == "Updated after 8 days" }
            }
        }
        assertTrue(updated.any { it.id == id })
    }

    @Test
    fun deleteRecord_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = JarvisFirestoreRepository(firestore)
        withTimeout(TIMEOUT_MS) {
            aliceRepo.addDeleteRecord(
                itemTitle = "Private.mp4",
                itemType = "video",
                sourceApp = "Gallery",
                details = "Alice private video",
                dateKey = "2026-11-13",
                deletedAtEpochMs = System.currentTimeMillis()
            )
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = JarvisFirestoreRepository(firestore)
        var capturedError: Exception? = null
        try {
            withTimeout(TIMEOUT_MS) {
                bobRepo.observeDeleteRecords(aliceUid).first()
            }
        } catch (e: Exception) {
            capturedError = e
        }
        val fsError = capturedError?.unwrapFirestoreException()
        assertNotNull("Expected FirebaseFirestoreException for cross-user read", fsError)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsError?.code)
    }

    @Test
    fun observeDeleteRecords_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = JarvisFirestoreRepository(firestore)
        var capturedError: Exception? = null
        try {
            withTimeout(TIMEOUT_MS) {
                repo.observeDeleteRecords("alice_uid_placeholder").first()
            }
        } catch (e: Exception) {
            capturedError = e
        }
        val fsError = capturedError?.unwrapFirestoreException()
        assertNotNull("Expected FirebaseFirestoreException for unauthenticated read", fsError)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsError?.code)
    }

    @Test
    fun userProfile_allowlist_socialReport_simPlan_crudSucceeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repo = JarvisFirestoreRepository(firestore)

        withTimeout(TIMEOUT_MS) {
            repo.ensureUserProfile(uid, "Tony")
            repo.updateUserPreferences(uid, preferredVoiceId = "iron_core_deep")
        }

        val profile = withTimeout(TIMEOUT_MS) {
            repo.observeUserProfile(uid).first { it != null && it.preferredVoiceId == "iron_core_deep" }
        }
        assertEquals("iron_core_deep", profile?.preferredVoiceId)

        val contactId = withTimeout(TIMEOUT_MS) {
            repo.saveAllowlistContact("Pepper", "+919876543210", "Family", isAllowlisted = true, isBlockedSpam = false)
        }
        val contacts = withTimeout(TIMEOUT_MS) {
            repo.observeAllowlistContacts(uid).first { list -> list.any { it.id == contactId } }
        }
        assertTrue(contacts.any { it.id == contactId && it.isAllowlisted })

        val reportId = withTimeout(TIMEOUT_MS) {
            repo.saveSocialReport(
                SocialReport(
                    platform = "facebook",
                    periodType = "daily",
                    dateKey = "2026-11-13",
                    totalFollowers = 1000,
                    newFollowers = 25,
                    viewsOrImpressions = 5000,
                    likes = 300,
                    comments = 40,
                    shares = 12,
                    messagesCount = 5,
                    earningsInr = 750.0,
                    dataSource = "Meta Business Suite"
                )
            )
        }
        val reports = withTimeout(TIMEOUT_MS) {
            repo.observeSocialReports(uid).first { list -> list.any { it.id == reportId } }
        }
        assertEquals(750.0, reports.first { it.id == reportId }.earningsInr, 0.01)

        withTimeout(TIMEOUT_MS) {
            repo.saveSimPlan(
                SimPlan(
                    simSlot = 1,
                    operatorName = "Jio",
                    planName = "299 True 5G",
                    planPriceInr = 299.0,
                    remainingDataGb = 1.5,
                    validityDays = 28,
                    expiryDateKey = "2026-12-11"
                )
            )
        }
        val plans = withTimeout(TIMEOUT_MS) {
            repo.observeSimPlans(uid).first { list -> list.any { it.simSlot == 1 } }
        }
        assertEquals("Jio", plans.first { it.simSlot == 1 }.operatorName)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_jarvis@test.com"
        const val BOB_EMAIL = "bob_jarvis@test.com"
        const val TIMEOUT_MS = 5000L
    }
}
